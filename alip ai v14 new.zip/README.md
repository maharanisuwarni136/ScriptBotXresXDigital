## Rules & Guidelines
1. Dilarang keras membagikan script secara cuma cuma.
2. Penjualan ( reseller only ) upgrade reseller ke **6381249703469**
5. Jangan menghapus credit yang ada di script.  
6. Permintaan fitur untuk update diperbolehkan, selama masuk akal.  
7. Bot akan selalu diperbarui dan dikembangkan secara berkala.

# RENAME SCRIP CUKUP BAGIAN ( SETTING.JS ) DILARANG KERAS BYPASS DB BOT/ATAU MENCOPOT SISTEM DB!!!

## Cara Menjalankan Script
1. Upload file ke panel hosting.  
2. Ekstrak (unarchive) file script.  
3. Pilih Node.js versi 23 atau lebih tinggi.  
4. Masukkan password pairing yang telah diberikan.  
5. Masukkan nomor bot.

## Cara pasang backup bot supaya database lama tidak hilang 
1. Upload sc versi terbaru, lalu unarchive
2. Upload file backup kalian, lalu unarchive
3. Restart.

© 2024-2025 @alifalfrl__

## New update v14.0.0

`fix fitur`
___________
1. apikey botcahx & alip ai yang sebelumnya kegabung sekarang udah dipisah
2. settings dibersihin, hapus config yang udah ga kepake
3. struktur plugin dirapiin pake subfolder, loader sekarang support baca folder otomatis
4. semua fitur game dipindah jadi plugin terpisah, nambah plugin before buat nerima jawaban game tanpa prefix
5. fix tebak lagu yang sebelumnya ngirim url, sekarang ngirim vn normal
6. fix bug validasi cpanel saat bikin server
7. fix sistem expired panel, auto suspend & cleanup jalan normal
8. nambah global error logger, bot ga force close kalau ada api error
9. nambah auto cleaner, file sampah dihapus otomatis tiap 1 jam
10. .addlist sekarang support video, foto, audio, dan stiker
11. fix fitur auto tutup/buka grup berjalan lancar
12. .jpm sekarang support video & foto
13. fix .getsc
14. fix .playch
15. fix antibot
16. antidelete dipindah ke .on/.off + support stiker, foto, video, dan text
17. perbaikan fitur .schedule realtime, otomatis kirim pesan sesuai tanggal yang ditentukan + hidetag
18. fix fake ff
19. .ai sekarang support generate gambar, detect gambar, dll
20. pemisahan menu premium + penambahan icon khusus premium/admin/owner di list menu
21. perbaikan .play, .playch, .ytmp4, dll
22. perbaikan fitur .iqc
23. perbaikan fitur .stalktiktok
24. perombakan fitur nsfw menggunakan database offline lokal (data/nsfw)
25. penambahan variabel baru di settings.js yaitu global.warngrup
26. fix .buatlagu
27. penambahan spotify downloader
28. migrasi seluruh fitur asupan ke database offline lokal (data/asupan)
29. migrasi fitur cecan, cogan, dan islami ke database offline lokal (data/cecan, data/cogan, data/islamic)
30. migrasi surah qur'an (.audiosurah) & kisah nabi (.kisahnabi) ke database offline lokal
31. perbaikan label tombol "menu cecan" menjadi "menu cecan & cogan" di semua style menu interaktif
32. alias menu anime/theme diubah dari .menu-potoanime menjadi .menu-animetheme di semua style menu
33. penambahan fitur reseller am (.addreselleram, .delreselleram, .listreselleram)
34. .fakecall
35. .fakeml

`new fitur`
___________
1. .toprompt
2. .swhd
3. anti tag all (.on/.off)
4. .readmore
5. notif gempa (.on/.off)
6. .caristiker
7. pemisahan 26 plugin random image ke folder plugins/random dengan awalan .random
8. penambahan tombol kategori menu asupan, menu random image, dan menu tools di semua style menu interaktif
9. integrasi pencarian 45 karakter anime theme langsung ke api botcahx
10. fitur reseller am & alight motion premium (.amprem, .addreselleram, .delreselleram, .listreselleram)
11. .autoai bisa vn, dan ganti suara vn
14. .setwelcome/.setleft sekarang udah bisa ganti foto, cukup reply foto welcome/left pake command .setwelcome/.setleft
15. fakedana

___________

ydhlah segini aja dlu, kelo kedepannya error gua fix terus, jadi santai aja🥰

btw up reseller, pt, own bisa ke wa.me//6281249703469

`remove fitur`
___________

 * ©alipai Since 2024 - 2026
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
