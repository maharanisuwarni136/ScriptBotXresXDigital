/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

require('../settings');

const fs = require('fs');
const chalk = require('chalk');

global.menusticker = `
╭╼ 🅂tickers 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Stickers Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .brat
┆𖢷 ׁ 𖹭₊ .bratvid
┆𖢷 ׁ 𖹭₊ .bratanime
┆𖢷 ׁ 𖹭₊ .bratgambar
┆𖢷 ׁ 𖹭₊ .bratgambarhd
┆𖢷 ׁ 𖹭₊ .bratimg3
┆𖢷 ׁ 𖹭₊ .bratpink
┆𖢷 ׁ 𖹭₊ .ytcomment
┆𖢷 ׁ 𖹭₊ .emoji
┆𖢷 ׁ 𖹭₊ .emojigif
┆𖢷 ׁ 𖹭₊ .emojimix
┆𖢷 ׁ 𖹭₊ .manusialidi
┆𖢷 ׁ 𖹭₊ .qc
┆𖢷 ׁ 𖹭₊ .smeme
┆𖢷 ׁ 𖹭₊ .sticker
┆𖢷 ׁ 𖹭₊ .stikeranime
┆𖢷 ׁ 𖹭₊ .stikerdinokuning
┆𖢷 ׁ 𖹭₊ .stikergojo
┆𖢷 ׁ 𖹭₊ .stikermukalu
┆𖢷 ׁ 𖹭₊ .stikerpentol
┆𖢷 ׁ 𖹭₊ .stikerrandom
┆𖢷 ׁ 𖹭₊ .stikerspongebob
┆𖢷 ׁ 𖹭₊ .swm
┆𖢷 ׁ 𖹭₊ .toimg
┆𖢷 ׁ 𖹭₊ .tvstiker
╰─╼𔕬─┈───┈───┈`

global.menutools = `
╭╼ 🅃ools 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Tools Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .swhd 🅟
┆𖢷 ׁ 𖹭₊ .web2apk
┆𖢷 ׁ 𖹭₊ .removeobject
┆𖢷 ׁ 𖹭₊ .toprompt 🅟
┆𖢷 ׁ 𖹭₊ .volume 🅟
┆𖢷 ׁ 𖹭₊ .volumevideo 🅟
┆𖢷 ׁ 𖹭₊ .img2pdf
┆𖢷 ׁ 𖹭₊ .ceknamadana
┆𖢷 ׁ 𖹭₊ .createhtml 🅟
┆𖢷 ׁ 𖹭₊ .saveweb
┆𖢷 ׁ 𖹭₊ .ttsbrando
┆𖢷 ׁ 𖹭₊ .ptvch 🅞
┆𖢷 ׁ 𖹭₊ .font1 - .font10
┆𖢷 ׁ 𖹭₊ .voicecover 🅟
┆𖢷 ׁ 𖹭₊ .vocalremover
┆𖢷 ׁ 𖹭₊ .tempo
┆𖢷 ׁ 𖹭₊ .speech2text
┆𖢷 ׁ 𖹭₊ .sidompul
┆𖢷 ׁ 𖹭₊ .togif
┆𖢷 ׁ 𖹭₊ .tovn
┆𖢷 ׁ 𖹭₊ .hdvid 🅟
┆𖢷 ׁ 𖹭₊ .tomp3
┆𖢷 ׁ 𖹭₊ .ai
┆𖢷 ׁ 𖹭₊ .aitts
┆𖢷 ׁ 𖹭₊ .ambilsw
┆𖢷 ׁ 𖹭₊ .donate
┆𖢷 ׁ 𖹭₊ .enc
┆𖢷 ׁ 𖹭₊ .enchard
┆𖢷 ׁ 𖹭₊ .fakecall
┆𖢷 ׁ 𖹭₊ .getpp
┆𖢷 ׁ 𖹭₊ .gptonline
┆𖢷 ׁ 𖹭₊ .gptimg
┆𖢷 ׁ 𖹭₊ .hd
┆𖢷 ׁ 𖹭₊ .iqc
┆𖢷 ׁ 𖹭₊ .kapanreset
┆𖢷 ׁ 𖹭₊ .ngl
┆𖢷 ׁ 𖹭₊ .nulis
┆𖢷 ׁ 𖹭₊ .ocr 🅟
┆𖢷 ׁ 𖹭₊ .rch
┆𖢷 ׁ 𖹭₊ .rvo 🅟
┆𖢷 ׁ 𖹭₊ .readmore
┆𖢷 ׁ 𖹭₊ .shortlink
┆𖢷 ׁ 𖹭₊ .shortlink2
┆𖢷 ׁ 𖹭₊ .ssweb
┆𖢷 ׁ 𖹭₊ .struk
┆𖢷 ׁ 𖹭₊ .texttosound
┆𖢷 ׁ 𖹭₊ .tourl
┆𖢷 ׁ 𖹭₊ .tourl2
┆𖢷 ׁ 𖹭₊ .tourl3
┆𖢷 ׁ 𖹭₊ .top4top
┆𖢷 ׁ 𖹭₊ .catbox
┆𖢷 ׁ 𖹭₊ .qu
┆𖢷 ׁ 𖹭₊ .uguu
┆𖢷 ׁ 𖹭₊ .pixhost
┆𖢷 ׁ 𖹭₊ .ytsummarizer
┆𖢷 ׁ 𖹭₊ .cfsub
┆𖢷 ׁ 𖹭₊ .listsubdo
┆𖢷 ׁ 𖹭₊ .delsubdo
┆𖢷 ׁ 𖹭₊ .infosubdo
┆𖢷 ׁ 𖹭₊ .syncsubdo
╰─╼𔕬─┈───┈───┈`

global.menuprem = `
╭╼ 🅟remium 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Premium Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .toprompt 🅟
┆𖢷 ׁ 𖹭₊ .swhd 🅟
┆𖢷 ׁ 𖹭₊ .createhtml 🅟
┆𖢷 ׁ 𖹭₊ .voicecover 🅟
┆𖢷 ׁ 𖹭₊ .hdvid 🅟
┆𖢷 ׁ 𖹭₊ .ocr 🅟
┆𖢷 ׁ 𖹭₊ .sharkstudio 🅟
┆𖢷 ׁ 𖹭₊ .alipedit 🅟
┆𖢷 ׁ 𖹭₊ .putihkan 🅟
┆𖢷 ׁ 𖹭₊ .aiedit 🅟
┆𖢷 ׁ 𖹭₊ .tobotak 🅟
┆𖢷 ׁ 𖹭₊ .tochibi 🅟
┆𖢷 ׁ 𖹭₊ .todino 🅟
┆𖢷 ׁ 𖹭₊ .polaroid 🅟
┆𖢷 ׁ 𖹭₊ .tofootball 🅟
┆𖢷 ׁ 𖹭₊ .animediff 🅟
┆𖢷 ׁ 𖹭₊ .tosunda 🅟
┆𖢷 ׁ 𖹭₊ .tomanga 🅟
┆𖢷 ׁ 𖹭₊ .tomangu 🅟
┆𖢷 ׁ 𖹭₊ .buatlagu 🅟
┆𖢷 ׁ 𖹭₊ .ghibli 🅟
┆𖢷 ׁ 𖹭₊ .nglspam 🅟
┆𖢷 ׁ 𖹭₊ .tokartun 🅟
┆𖢷 ׁ 𖹭₊ .veo3 🅟
┆𖢷 ׁ 𖹭₊ .mediafire 🅟
┆𖢷 ׁ 𖹭₊ .play1 🅟
┆𖢷 ׁ 𖹭₊ .soraai 🅟
┆𖢷 ׁ 𖹭₊ .tebakff 🅟
┆𖢷 ׁ 𖹭₊ .nsfwneko 🅟
┆𖢷 ׁ 𖹭₊ .nsfw 🅟
┆𖢷 ׁ 𖹭₊ .nsfwahegao 🅟
┆𖢷 ׁ 𖹭₊ .nsfwass 🅟
┆𖢷 ׁ 𖹭₊ .nsfwbdsm 🅟
┆𖢷 ׁ 𖹭₊ .nsfwcum 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgangbang 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgay 🅟
┆𖢷 ׁ 𖹭₊ .nsfwhentai 🅟
┆𖢷 ׁ 𖹭₊ .nsfwkasedaiki 🅟
┆𖢷 ׁ 𖹭₊ .nsfwloli 🅟
┆𖢷 ׁ 𖹭₊ .nsfwmasturbation 🅟
┆𖢷 ׁ 𖹭₊ .nsfwopai 🅟
┆𖢷 ׁ 𖹭₊ .nsfwpussy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwzettai 🅟
┆𖢷 ׁ 𖹭₊ .animensfwloli 🅟
┆𖢷 ׁ 𖹭₊ .todemo 🅟
┆𖢷 ׁ 𖹭₊ .rvo 🅟
┆𖢷 ׁ 𖹭₊ .img2video 🅟
┆𖢷 ׁ 𖹭₊ .duckai 🅟
┆𖢷 ׁ 𖹭₊ .volume 🅟
┆𖢷 ׁ 𖹭₊ .volumevideo 🅟
┆𖢷 ׁ 𖹭₊ .aiundress 🅟
┆𖢷 ׁ 𖹭₊ .confes 🅟
┆𖢷 ׁ 𖹭₊ .genvideo 🅟
┆𖢷 ׁ 𖹭₊ .jawab 🅟
┆𖢷 ׁ 𖹭₊ .editai 🅟
╰─╼𔕬─┈───┈───┈`

global.menumaker = `
╭╼ 🄼aker 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Maker Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .todemo 🅟
┆𖢷 ׁ 𖹭₊ .fakewhatsapp
┆𖢷 ׁ 𖹭₊ .wanted
┆𖢷 ׁ 𖹭₊ .musikcard
┆𖢷 ׁ 𖹭₊ .fakeff
┆𖢷 ׁ 𖹭₊ .fakedana
┆𖢷 ׁ 𖹭₊ .topenjara
┆𖢷 ׁ 𖹭₊ .sharkstudio 🅟
┆𖢷 ׁ 𖹭₊ .alipedit 🅟
┆𖢷 ׁ 𖹭₊ .putihkan 🅟
┆𖢷 ׁ 𖹭₊ .aiedit 🅟
┆𖢷 ׁ 𖹭₊ .banana
┆𖢷 ׁ 𖹭₊ .hijabpin
┆𖢷 ׁ 𖹭₊ .hitamin
┆𖢷 ׁ 𖹭₊ .tobotak 🅟
┆𖢷 ׁ 𖹭₊ .tomountain
┆𖢷 ׁ 𖹭₊ .tochibi 🅟
┆𖢷 ׁ 𖹭₊ .todino 🅟
┆𖢷 ׁ 𖹭₊ .polaroid 🅟
┆𖢷 ׁ 𖹭₊ .tofootball 🅟
┆𖢷 ׁ 𖹭₊ .animediff 🅟
┆𖢷 ׁ 𖹭₊ .photoai
┆𖢷 ׁ 𖹭₊ .carbon
┆𖢷 ׁ 𖹭₊ .tofigure
┆𖢷 ׁ 𖹭₊ .telanjang
┆𖢷 ׁ 𖹭₊ .fakestory
┆𖢷 ׁ 𖹭₊ .tosunda 🅟
┆𖢷 ׁ 𖹭₊ .tojawa
┆𖢷 ׁ 𖹭₊ .todonghua
┆𖢷 ׁ 𖹭₊ .tomanhwa
┆𖢷 ׁ 𖹭₊ .toanime
┆𖢷 ׁ 𖹭₊ .tomanga 🅟
┆𖢷 ׁ 𖹭₊ .sdm
┆𖢷 ׁ 𖹭₊ .tomoai
┆𖢷 ׁ 𖹭₊ .topacar
┆𖢷 ׁ 𖹭₊ .tomonyet
┆𖢷 ׁ 𖹭₊ .tosatan
┆𖢷 ׁ 𖹭₊ .toroblox
┆𖢷 ׁ 𖹭₊ .topunk
┆𖢷 ׁ 𖹭₊ .tomangu 🅟
┆𖢷 ׁ 𖹭₊ .tosad
┆𖢷 ׁ 𖹭₊ .todpr
┆𖢷 ׁ 𖹭₊ .tobabi
┆𖢷 ׁ 𖹭₊ .buatgambar
┆𖢷 ׁ 𖹭₊ .buatlagu 🅟
┆𖢷 ׁ 𖹭₊ .buatvideo
┆𖢷 ׁ 𖹭₊ .ghibli 🅟
┆𖢷 ׁ 𖹭₊ .jadidisney
┆𖢷 ׁ 𖹭₊ .jadigta
┆𖢷 ׁ 𖹭₊ .jadipixar
┆𖢷 ׁ 𖹭₊ .nglspam 🅟
┆𖢷 ׁ 𖹭₊ .tokartun 🅟
┆𖢷 ׁ 𖹭₊ .veo3 🅟
┆𖢷 ׁ 𖹭₊ .zrooart
┆𖢷 ׁ 𖹭₊ .tospiderman
┆𖢷 ׁ 𖹭₊ .tonaruto
┆𖢷 ׁ 𖹭₊ .tobatman
┆𖢷 ׁ 𖹭₊ .tosuperman
┆𖢷 ׁ 𖹭₊ .toironman
┆𖢷 ׁ 𖹭₊ .tocaptainamerica
┆𖢷 ׁ 𖹭₊ .tothor
┆𖢷 ׁ 𖹭₊ .tohulk
┆𖢷 ׁ 𖹭₊ .towolverine
┆𖢷 ׁ 𖹭₊ .todeadpool
┆𖢷 ׁ 𖹭₊ .toflash
┆𖢷 ׁ 𖹭₊ .toaquaman
┆𖢷 ׁ 𖹭₊ .tocyan
┆𖢷 ׁ 𖹭₊ .tovision
┆𖢷 ׁ 𖹭₊ .toblackpanther
┆𖢷 ׁ 𖹭₊ .tostarlord
┆𖢷 ׁ 𖹭₊ .togroot
┆𖢷 ׁ 𖹭₊ .torocket
┆𖢷 ׁ 𖹭₊ .todracula
┆𖢷 ׁ 𖹭₊ .tofrankenstein
┆𖢷 ׁ 𖹭₊ .tozombie
┆𖢷 ׁ 𖹭₊ .tovampire
┆𖢷 ׁ 𖹭₊ .toghost
┆𖢷 ׁ 𖹭₊ .toskeleton
┆𖢷 ׁ 𖹭₊ .todevil
┆𖢷 ׁ 𖹭₊ .toangel
┆𖢷 ׁ 𖹭₊ .tofairy
┆𖢷 ׁ 𖹭₊ .towizard
┆𖢷 ׁ 𖹭₊ .towinged
┆𖢷 ׁ 𖹭₊ .toelf
┆𖢷 ׁ 𖹭₊ .todwarf
┆𖢷 ׁ 𖹭₊ .toorc
┆𖢷 ׁ 𖹭₊ .totroll
┆𖢷 ׁ 𖹭₊ .togiant
┆𖢷 ׁ 𖹭₊ .tominotaur
┆𖢷 ׁ 𖹭₊ .tomedusa
┆𖢷 ׁ 𖹭₊ .tocentaur
┆𖢷 ׁ 𖹭₊ .togriffin
┆𖢷 ׁ 𖹭₊ .tophoenix
┆𖢷 ׁ 𖹭₊ .todragon
┆𖢷 ׁ 𖹭₊ .tounicorn
┆𖢷 ׁ 𖹭₊ .topeacock
┆𖢷 ׁ 𖹭₊ .towolf
┆𖢷 ׁ 𖹭₊ .tofox
┆𖢷 ׁ 𖹭₊ .tobear
┆𖢷 ׁ 𖹭₊ .tolion
┆𖢷 ׁ 𖹭₊ .totiger
┆𖢷 ׁ 𖹭₊ .topanda
┆𖢷 ׁ 𖹭₊ .tokoala
┆𖢷 ׁ 𖹭₊ .topenguin
┆𖢷 ׁ 𖹭₊ .toowl
┆𖢷 ׁ 𖹭₊ .toeagle
┆𖢷 ׁ 𖹭₊ .tofalcon
┆𖢷 ׁ 𖹭₊ .toraven
┆𖢷 ׁ 𖹭₊ .tocrow
┆𖢷 ׁ 𖹭₊ .tosnake
┆𖢷 ׁ 𖹭₊ .toshark
┆𖢷 ׁ 𖹭₊ .tocrocodile
┆𖢷 ׁ 𖹭₊ .tooctopus
┆𖢷 ׁ 𖹭₊ .tojellyfish
┆𖢷 ׁ 𖹭₊ .tostarfish
┆𖢷 ׁ 𖹭₊ .toseahorse
┆𖢷 ׁ 𖹭₊ .todolphin
┆𖢷 ׁ 𖹭₊ .towhale
┆𖢷 ׁ 𖹭₊ .torobot
┆𖢷 ׁ 𖹭₊ .tocyborg
┆𖢷 ׁ 𖹭₊ .toandroid
┆𖢷 ׁ 𖹭₊ .toalien
┆𖢷 ׁ 𖹭₊ .toufo
┆𖢷 ׁ 𖹭₊ .toastronaut
┆𖢷 ׁ 𖹭₊ .tocosmonaut
┆𖢷 ׁ 𖹭₊ .toscuba
┆𖢷 ׁ 𖹭₊ .todiver
┆𖢷 ׁ 𖹭₊ .topirate
┆𖢷 ׁ 𖹭₊ .tocowboy
┆𖢷 ׁ 𖹭₊ .toninja
┆𖢷 ׁ 𖹭₊ .tosamurai
┆𖢷 ׁ 𖹭₊ .toviking
┆𖢷 ׁ 𖹭₊ .toknight
┆𖢷 ׁ 𖹭₊ .toarcher
┆𖢷 ׁ 𖹭₊ .tomage
┆𖢷 ׁ 𖹭₊ .tocleric
┆𖢷 ׁ 𖹭₊ .tobard
┆𖢷 ׁ 𖹭₊ .torogue
┆𖢷 ׁ 𖹭₊ .tomonk
┆𖢷 ׁ 𖹭₊ .tobarbarian
┆𖢷 ׁ 𖹭₊ .tonecromancer
┆𖢷 ׁ 𖹭₊ .todruid
┆𖢷 ׁ 𖹭₊ .toranger
┆𖢷 ׁ 𖹭₊ .topaladin
┆𖢷 ׁ 𖹭₊ .togunslinger
┆𖢷 ׁ 𖹭₊ .tomechanic
┆𖢷 ׁ 𖹭₊ .toscientist
┆𖢷 ׁ 𖹭₊ .todoctor
┆𖢷 ׁ 𖹭₊ .toengineer
┆𖢷 ׁ 𖹭₊ .toartist
┆𖢷 ׁ 𖹭₊ .tosinger
┆𖢷 ׁ 𖹭₊ .todancer
┆𖢷 ׁ 𖹭₊ .toactor
┆𖢷 ׁ 𖹭₊ .todirector
┆𖢷 ׁ 𖹭₊ .towriter
┆𖢷 ׁ 𖹭₊ .tophotographer
┆𖢷 ׁ 𖹭₊ .tochef
┆𖢷 ׁ 𖹭₊ .tobaker
┆𖢷 ׁ 𖹭₊ .tobarista
┆𖢷 ׁ 𖹭₊ .tobartender
┆𖢷 ׁ 𖹭₊ .topilot
┆𖢷 ׁ 𖹭₊ .todriver
┆𖢷 ׁ 𖹭₊ .tosailor
┆𖢷 ׁ 𖹭₊ .tosoldier
┆𖢷 ׁ 𖹭₊ .topoliceman
┆𖢷 ׁ 𖹭₊ .tofirefighter
┆𖢷 ׁ 𖹭₊ .toteacher
┆𖢷 ׁ 𖹭₊ .toprofessor
┆𖢷 ׁ 𖹭₊ .tostudent
┆𖢷 ׁ 𖹭₊ .toprogrammer
┆𖢷 ׁ 𖹭₊ .todesigner
┆𖢷 ׁ 𖹭₊ .totester
┆𖢷 ׁ 𖹭₊ .tomanager
┆𖢷 ׁ 𖹭₊ .toboss
┆𖢷 ׁ 𖹭₊ .toceo
┆𖢷 ׁ 𖹭₊ .tocfo
┆𖢷 ׁ 𖹭₊ .tocoo
┆𖢷 ׁ 𖹭₊ .tocmo
┆𖢷 ׁ 𖹭₊ .tocto
┆𖢷 ׁ 𖹭₊ .tocpo
┆𖢷 ׁ 𖹭₊ .tocko
┆𖢷 ׁ 𖹭₊ .toclown
┆𖢷 ׁ 𖹭₊ .tomime
┆𖢷 ׁ 𖹭₊ .tojester
┆𖢷 ׁ 𖹭₊ .tomagician
┆𖢷 ׁ 𖹭₊ .toillusionist
┆𖢷 ׁ 𖹭₊ .toescapeartist
┆𖢷 ׁ 𖹭₊ .toacrobat
┆𖢷 ׁ 𖹭₊ .tocontortionist
┆𖢷 ׁ 𖹭₊ .toswordswallower
┆𖢷 ׁ 𖹭₊ .tofirebreather
┆𖢷 ׁ 𖹭₊ .tojugger
┆𖢷 ׁ 𖹭₊ .tounicyclist
┆𖢷 ׁ 𖹭₊ .totightrope
┆𖢷 ׁ 𖹭₊ .totrapeze
┆𖢷 ׁ 𖹭₊ .toaerialist
┆𖢷 ׁ 𖹭₊ .tocannon
┆𖢷 ׁ 𖹭₊ .tostilts
┆𖢷 ׁ 𖹭₊ .tomask
┆𖢷 ׁ 𖹭₊ .tomummy
┆𖢷 ׁ 𖹭₊ .tozorro
┆𖢷 ׁ 𖹭₊ .tosherlock
┆𖢷 ׁ 𖹭₊ .tophantom
┆𖢷 ׁ 𖹭₊ .todraco
┆𖢷 ׁ 𖹭₊ .tohannibal
┆𖢷 ׁ 𖹭₊ .tojoker
┆𖢷 ׁ 𖹭₊ .tovenom
┆𖢷 ׁ 𖹭₊ .tocarnage
┆𖢷 ׁ 𖹭₊ .togreen
┆𖢷 ׁ 𖹭₊ .tolizard
┆𖢷 ׁ 𖹭₊ .torhino
┆𖢷 ׁ 𖹭₊ .tovulture
┆𖢷 ׁ 𖹭₊ .toelectro
┆𖢷 ׁ 𖹭₊ .tosandman
┆𖢷 ׁ 𖹭₊ .tomysterio
┆𖢷 ׁ 𖹭₊ .togoblin
┆𖢷 ׁ 𖹭₊ .tochemo
┆𖢷 ׁ 𖹭₊ .toloki
┆𖢷 ׁ 𖹭₊ .tothanos
┆𖢷 ׁ 𖹭₊ .togalactus
┆𖢷 ׁ 𖹭₊ .todarkseid
┆𖢷 ׁ 𖹭₊ .tobrainiac
┆𖢷 ׁ 𖹭₊ .todoomsday
┆𖢷 ׁ 𖹭₊ .tobizarro
┆𖢷 ׁ 𖹭₊ .tometallo
┆𖢷 ׁ 𖹭₊ .toparasite
┆𖢷 ׁ 𖹭₊ .togrodd
┆𖢷 ׁ 𖹭₊ .tocircus
┆𖢷 ׁ 𖹭₊ .toreverse
┆𖢷 ׁ 𖹭₊ .tomirror
┆𖢷 ׁ 𖹭₊ .togold
┆𖢷 ׁ 𖹭₊ .tosilver
┆𖢷 ׁ 𖹭₊ .tobronze
┆𖢷 ׁ 𖹭₊ .tocopper
┆𖢷 ׁ 𖹭₊ .tosteel
┆𖢷 ׁ 𖹭₊ .tocarbon
┆𖢷 ׁ 𖹭₊ .tocrystal
┆𖢷 ׁ 𖹭₊ .todiamond
┆𖢷 ׁ 𖹭₊ .tosapphire
┆𖢷 ׁ 𖹭₊ .toruby
┆𖢷 ׁ 𖹭₊ .toemerald
┆𖢷 ׁ 𖹭₊ .totopaz
┆𖢷 ׁ 𖹭₊ .toamethyst
┆𖢷 ׁ 𖹭₊ .toopal
┆𖢷 ׁ 𖹭₊ .toperidot
┆𖢷 ׁ 𖹭₊ .toaquamarine
┆𖢷 ׁ 𖹭₊ .tocitrine
┆𖢷 ׁ 𖹭₊ .totourmaline
┆𖢷 ׁ 𖹭₊ .togarnet
┆𖢷 ׁ 𖹭₊ .tospinel
┆𖢷 ׁ 𖹭₊ .tozircon
┆𖢷 ׁ 𖹭₊ .totanzanite
┆𖢷 ׁ 𖹭₊ .toiolite
┆𖢷 ׁ 𖹭₊ .tohematite
┆𖢷 ׁ 𖹭₊ .tomoonstone
┆𖢷 ׁ 𖹭₊ .tosunstone
┆𖢷 ׁ 𖹭₊ .tostarstone
┆𖢷 ׁ 𖹭₊ .tocomet
┆𖢷 ׁ 𖹭₊ .tometeor
┆𖢷 ׁ 𖹭₊ .toasteroid
┆𖢷 ׁ 𖹭₊ .tonebula
┆𖢷 ׁ 𖹭₊ .togalaxy
┆𖢷 ׁ 𖹭₊ .touniverse
┆𖢷 ׁ 𖹭₊ .toblackhole
┆𖢷 ׁ 𖹭₊ .towormhole
┆𖢷 ׁ 𖹭₊ .toportal
┆𖢷 ׁ 𖹭₊ .totime
┆𖢷 ׁ 𖹭₊ .tospace
┆𖢷 ׁ 𖹭₊ .todimension
┆𖢷 ׁ 𖹭₊ .toparallel
┆𖢷 ׁ 𖹭₊ .toalternate
┆𖢷 ׁ 𖹭₊ .tomultiverse
┆𖢷 ׁ 𖹭₊ .tomegaverse
┆𖢷 ׁ 𖹭₊ .tometaverse
┆𖢷 ׁ 𖹭₊ .toomniverse
╰─╼𔕬─┈───┈───┈`

global.menuprimbon = `
╭╼ 🄿rimbon 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Primbon Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .artinama
┆𖢷 ׁ 𖹭₊ .cekaura
┆𖢷 ׁ 𖹭₊ .ceksial
┆𖢷 ׁ 𖹭₊ .darkjoke
┆𖢷 ׁ 𖹭₊ .isidompet
┆𖢷 ׁ 𖹭₊ .jodohmakanan
┆𖢷 ׁ 𖹭₊ .kecocokannama
┆𖢷 ׁ 𖹭₊ .nasibbatere
┆𖢷 ׁ 𖹭₊ .nomerhoki
┆𖢷 ׁ 𖹭₊ .pantun
┆𖢷 ׁ 𖹭₊ .profesiku
┆𖢷 ׁ 𖹭₊ .quotes
┆𖢷 ׁ 𖹭₊ .ramalancinta
┆𖢷 ׁ 𖹭₊ .ramalanjodoh
┆𖢷 ׁ 𖹭₊ .ramalanjodohbali
┆𖢷 ׁ 𖹭₊ .ramalannasib
┆𖢷 ׁ 𖹭₊ .scankontol
┆𖢷 ׁ 𖹭₊ .scanmemek
┆𖢷 ׁ 𖹭₊ .suamiistri
┆𖢷 ׁ 𖹭₊ .zodiak
╰─╼𔕬─┈───┈───┈`

global.menufun = `
╭╼ 🄵un 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Fun Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .fitnah
┆𖢷 ׁ 𖹭₊ .sad1
┆𖢷 ׁ 𖹭₊ .sound1
┆𖢷 ׁ 𖹭₊ .artinama
┆𖢷 ׁ 𖹭₊ .cekbeban
┆𖢷 ׁ 𖹭₊ .cekbucin
┆𖢷 ׁ 𖹭₊ .cekfemboy
┆𖢷 ׁ 𖹭₊ .cekgay
┆𖢷 ׁ 𖹭₊ .cekjodoh
┆𖢷 ׁ 𖹭₊ .cekjones
┆𖢷 ׁ 𖹭₊ .cekkaya
┆𖢷 ׁ 𖹭₊ .cekkodam
┆𖢷 ׁ 𖹭₊ .cekkontol
┆𖢷 ׁ 𖹭₊ .cekmasadepan
┆𖢷 ׁ 𖹭₊ .cekmemek
┆𖢷 ׁ 𖹭₊ .ceksange
┆𖢷 ׁ 𖹭₊ .cekstress
┆𖢷 ׁ 𖹭₊ .cekwibu
┆𖢷 ׁ 𖹭₊ .fakeml
┆𖢷 ׁ 𖹭₊ .faktadunia
┆𖢷 ׁ 𖹭₊ .faktaunik
┆𖢷 ׁ 𖹭₊ .infonegara
┆𖢷 ׁ 𖹭₊ .jumlahuser
┆𖢷 ׁ 𖹭₊ .kecocokanpasangan
┆𖢷 ׁ 𖹭₊ .kirimch 🅞
┆𖢷 ׁ 𖹭₊ .meme
┆𖢷 ׁ 𖹭₊ .pakustad
┆𖢷 ׁ 𖹭₊ .planet
┆𖢷 ׁ 𖹭₊ .quotesanime
┆𖢷 ׁ 𖹭₊ .sertifikattolol
┆𖢷 ׁ 𖹭₊ .tafsirmimpi
┆𖢷 ׁ 𖹭₊ .waifu
┆𖢷 ׁ 𖹭₊ .confes 🅟
╰─╼𔕬─┈───┈───┈`

global.menudownload = `
╭╼ 🄳ownload 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Download Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .tiktok
┆𖢷 ׁ 𖹭₊ .tiktokmp3
┆𖢷 ׁ 𖹭₊ .twitter
┆𖢷 ׁ 𖹭₊ .ytmp3
┆𖢷 ׁ 𖹭₊ .ytmp4
┆𖢷 ׁ 𖹭₊ .pinterest
┆𖢷 ׁ 𖹭₊ .pindl
┆𖢷 ׁ 𖹭₊ .alipdl
┆𖢷 ׁ 𖹭₊ .capcut
┆𖢷 ׁ 𖹭₊ .facebook
┆𖢷 ׁ 𖹭₊ .gitclone
┆𖢷 ׁ 𖹭₊ .gdrive
┆𖢷 ׁ 𖹭₊ .instagram
┆𖢷 ׁ 𖹭₊ .mediafire 🅟
┆𖢷 ׁ 𖹭₊ .pastebin
┆𖢷 ׁ 𖹭₊ .play1 🅟
┆𖢷 ׁ 𖹭₊ .spdown
┆𖢷 ׁ 𖹭₊ .telesticker
┆𖢷 ׁ 𖹭₊ .threads
╰─╼𔕬─┈───┈───┈`

global.menuasupan = `
╭╼ 🄰supan 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Asupan Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .asupan
┆𖢷 ׁ 𖹭₊ .asupanbocil
┆𖢷 ׁ 𖹭₊ .asupandouyin
┆𖢷 ׁ 𖹭₊ .asupangeayubi
┆𖢷 ׁ 𖹭₊ .asupangheayubi
┆𖢷 ׁ 𖹭₊ .asupanhijaber
┆𖢷 ׁ 𖹭₊ .asupanrikagusriani
┆𖢷 ׁ 𖹭₊ .asupansantuy
┆𖢷 ׁ 𖹭₊ .asupanukhty
╰─╼𔕬─┈───┈───┈`

global.menucecan = `
╭╼ 🄲ecan & 🄲ogan 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Cecan & Cogan Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .cecan
┆𖢷 ׁ 𖹭₊ .cecanchina
┆𖢷 ׁ 𖹭₊ .cecanhijaber
┆𖢷 ׁ 𖹭₊ .cecanindonesia
┆𖢷 ׁ 𖹭₊ .cecanjapan
┆𖢷 ׁ 𖹭₊ .cecankorea
┆𖢷 ׁ 𖹭₊ .cecanmalaysia
┆𖢷 ׁ 𖹭₊ .cecanrandom
┆𖢷 ׁ 𖹭₊ .cecanthailand
┆𖢷 ׁ 𖹭₊ .cecanvietnam
┆𖢷 ׁ 𖹭₊ .cogan
╰─╼𔕬─┈───┈───┈`

global.menurandom = `
╭╼ 🅁andom 🄸mage 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Random Image Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .randommeme
┆𖢷 ׁ 𖹭₊ .randomaesthetic
┆𖢷 ׁ 𖹭₊ .randomanjing
┆𖢷 ׁ 𖹭₊ .randomantiwork
┆𖢷 ׁ 𖹭₊ .randomblackpink
┆𖢷 ׁ 𖹭₊ .randomboneka
┆𖢷 ׁ 𖹭₊ .randomcecan
┆𖢷 ׁ 𖹭₊ .randomcogan
┆𖢷 ׁ 𖹭₊ .randomcosplay
┆𖢷 ׁ 𖹭₊ .randomdadu
┆𖢷 ׁ 𖹭₊ .randomhekel
┆𖢷 ׁ 𖹭₊ .randomjustina
┆𖢷 ׁ 𖹭₊ .randomkayes
┆𖢷 ׁ 𖹭₊ .randomkpop
┆𖢷 ׁ 𖹭₊ .randomkucing
┆𖢷 ׁ 𖹭₊ .randommobil
┆𖢷 ׁ 𖹭₊ .randommotor
┆𖢷 ׁ 𖹭₊ .randomnotnot
┆𖢷 ׁ 𖹭₊ .randomppcp
┆𖢷 ׁ 𖹭₊ .randomprofile
┆𖢷 ׁ 𖹭₊ .randompubg
┆𖢷 ׁ 𖹭₊ .randomquotenime
┆𖢷 ׁ 𖹭₊ .randomrose
┆𖢷 ׁ 𖹭₊ .randomryujin
┆𖢷 ׁ 𖹭₊ .randomwallhp
┆𖢷 ׁ 𖹭₊ .randomwallml
╰─╼𔕬─┈───┈───┈`

global.menupanel = `
╭╼ 🄿anel 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Panel Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .1gb
┆𖢷 ׁ 𖹭₊ .2gb
┆𖢷 ׁ 𖹭₊ .3gb
┆𖢷 ׁ 𖹭₊ .4gb
┆𖢷 ׁ 𖹭₊ .5gb
┆𖢷 ׁ 𖹭₊ .6gb
┆𖢷 ׁ 𖹭₊ .7gb
┆𖢷 ׁ 𖹭₊ .unli
┆𖢷 ׁ 𖹭₊ .mypanel
┆𖢷 ׁ 𖹭₊ .listpanel
┆𖢷 ׁ 𖹭₊ .listuser
┆𖢷 ׁ 𖹭₊ .renewserver
┆𖢷 ׁ 𖹭₊ .notif
┆𖢷 ׁ 𖹭₊ .delsrv
┆𖢷 ׁ 𖹭₊ .deluser
┆𖢷 ׁ 𖹭₊ .setpanel 🅞
┆𖢷 ׁ 𖹭₊ .installpanel 🅞
┆𖢷 ׁ 𖹭₊ .addreseller
┆𖢷 ׁ 𖹭₊ .cekres
┆𖢷 ׁ 𖹭₊ .delreseller 🅞
┆𖢷 ׁ 𖹭₊ .listreseller 🅞
┆𖢷 ׁ 𖹭₊ .cadp
╰─╼𔕬─┈───┈───┈`

global.menunsfw = `
╭╼ 🄽🅂🄵🅆 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *NSFW Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .nsfw 🅟
┆𖢷 ׁ 𖹭₊ .nsfwahegao 🅟
┆𖢷 ׁ 𖹭₊ .nsfwass 🅟
┆𖢷 ׁ 𖹭₊ .nsfwbdsm 🅟
┆𖢷 ׁ 𖹭₊ .nsfwblowjob 🅟
┆𖢷 ׁ 𖹭₊ .nsfwcuckold 🅟
┆𖢷 ׁ 𖹭₊ .nsfwcum 🅟
┆𖢷 ׁ 𖹭₊ .nsfweba 🅟
┆𖢷 ׁ 𖹭₊ .nsfwero 🅟
┆𖢷 ׁ 𖹭₊ .nsfwfemdom 🅟
┆𖢷 ׁ 𖹭₊ .nsfwfoot 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgangbang 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgifs 🅟
┆𖢷 ׁ 𖹭₊ .nsfwglasses 🅟
┆𖢷 ׁ 𖹭₊ .nsfwhentai 🅟
┆𖢷 ׁ 𖹭₊ .nsfwjahy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwmanga 🅟
┆𖢷 ׁ 𖹭₊ .nsfwmasturbation 🅟
┆𖢷 ׁ 𖹭₊ .nsfwneko 🅟
┆𖢷 ׁ 𖹭₊ .nsfwneko2 🅟
┆𖢷 ׁ 𖹭₊ .nsfwloli 🅟
┆𖢷 ׁ 𖹭₊ .nsfworgy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwpanties 🅟
┆𖢷 ׁ 𖹭₊ .nsfwpussy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwtentacles 🅟
┆𖢷 ׁ 𖹭₊ .nsfwthighs 🅟
┆𖢷 ׁ 𖹭₊ .nsfwyuri 🅟
┆𖢷 ׁ 𖹭₊ .nsfwzettai 🅟
╰─╼𔕬─┈───┈───┈`

global.menuai = `
╭╼ 🄰I 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *AI Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .duckai 🅟
┆𖢷 ׁ 𖹭₊ .luma
┆𖢷 ׁ 𖹭₊ .img2video 🅟
┆𖢷 ׁ 𖹭₊ .copilotvoice
┆𖢷 ׁ 𖹭₊ .aimention
┆𖢷 ׁ 𖹭₊ .publicai
┆𖢷 ׁ 𖹭₊ .powerbrain
┆𖢷 ׁ 𖹭₊ .venice
┆𖢷 ׁ 𖹭₊ .webpilot
┆𖢷 ׁ 𖹭₊ .logicbell
┆𖢷 ׁ 𖹭₊ .bard
┆𖢷 ׁ 𖹭₊ .hyperai
┆𖢷 ׁ 𖹭₊ .autoai
┆𖢷 ׁ 𖹭₊ .ai
┆𖢷 ׁ 𖹭₊ .airealtime
┆𖢷 ׁ 𖹭₊ .gpt5plus
┆𖢷 ׁ 𖹭₊ .soraai 🅟
┆𖢷 ׁ 𖹭₊ .openai
┆𖢷 ׁ 𖹭₊ .groq
┆𖢷 ׁ 𖹭₊ .customai
┆𖢷 ׁ 𖹭₊ .aiundress 🅟
┆𖢷 ׁ 𖹭₊ .genvideo 🅟
┆𖢷 ׁ 𖹭₊ .editai 🅟
╰─╼𔕬─┈───┈───┈`

global.menusearch = `
╭╼ 🅂earch 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Search Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .toproblox
┆𖢷 ׁ 𖹭₊ .gsmarena
┆𖢷 ׁ 𖹭₊ .soundcloud
┆𖢷 ׁ 𖹭₊ .npmjs
┆𖢷 ׁ 𖹭₊ .whatmusik
┆𖢷 ׁ 𖹭₊ .lirik
┆𖢷 ׁ 𖹭₊ .ptv
┆𖢷 ׁ 𖹭₊ .myanimelist
┆𖢷 ׁ 𖹭₊ .searchanime
┆𖢷 ׁ 𖹭₊ .animeinfo
┆𖢷 ׁ 𖹭₊ .searchchar
┆𖢷 ׁ 𖹭₊ .charinfo
┆𖢷 ׁ 𖹭₊ .carigrupwa
┆𖢷 ׁ 𖹭₊ .caristiker
┆𖢷 ׁ 𖹭₊ .cekgempa
┆𖢷 ׁ 𖹭₊ .cekml
┆𖢷 ׁ 𖹭₊ .cekff
┆𖢷 ׁ 𖹭₊ .cekcuaca
┆𖢷 ׁ 𖹭₊ .cnbc
┆𖢷 ׁ 𖹭₊ .cnn
┆𖢷 ׁ 𖹭₊ .hiitwixtor
┆𖢷 ׁ 𖹭₊ .igstalk
┆𖢷 ׁ 𖹭₊ .otakudesu
┆𖢷 ׁ 𖹭₊ .pinterest
┆𖢷 ׁ 𖹭₊ .play
┆𖢷 ׁ 𖹭₊ .playch 🅞
┆𖢷 ׁ 𖹭₊ .playtiktok
┆𖢷 ׁ 𖹭₊ .playv2
┆𖢷 ׁ 𖹭₊ .playvid
┆𖢷 ׁ 𖹭₊ .spotify
┆𖢷 ׁ 𖹭₊ .stalkroblox
┆𖢷 ׁ 𖹭₊ .tiktokstalk
┆𖢷 ׁ 𖹭₊ .yts
╰─╼𔕬─┈───┈───┈`

global.menugame = `
╭╼ 🄶ame 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Game Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .tictactoe
┆𖢷 ׁ 𖹭₊ .kuismath
┆𖢷 ׁ 𖹭₊ .sambungkata
┆𖢷 ׁ 𖹭₊ .sambungkata2
┆𖢷 ׁ 𖹭₊ .tebakhero
┆𖢷 ׁ 𖹭₊ .tebakgenshin
┆𖢷 ׁ 𖹭₊ .asahotak
┆𖢷 ׁ 𖹭₊ .bom
┆𖢷 ׁ 𖹭₊ .caklontong
┆𖢷 ׁ 𖹭₊ .family100
┆𖢷 ׁ 𖹭₊ .kuis
┆𖢷 ׁ 𖹭₊ .lengkapikalimat
┆𖢷 ׁ 𖹭₊ .siapakahaku
┆𖢷 ׁ 𖹭₊ .susunkata
┆𖢷 ׁ 𖹭₊ .tebakanime
┆𖢷 ׁ 𖹭₊ .tebakbendera
┆𖢷 ׁ 𖹭₊ .tebakff 🅟
┆𖢷 ׁ 𖹭₊ .tebakgame
┆𖢷 ׁ 𖹭₊ .tebakgambar
┆𖢷 ׁ 𖹭₊ .tebakhewan
┆𖢷 ׁ 𖹭₊ .tebakinggris
┆𖢷 ׁ 𖹭₊ .tebakjkt
┆𖢷 ׁ 𖹭₊ .tebakjorok
┆𖢷 ׁ 𖹭₊ .tebakkah
┆𖢷 ׁ 𖹭₊ .tebakkalimat
┆𖢷 ׁ 𖹭₊ .tebakkata
┆𖢷 ׁ 𖹭₊ .tebaklagu
┆𖢷 ׁ 𖹭₊ .tebaklirik
┆𖢷 ׁ 𖹭₊ .tebaklogo
┆𖢷 ׁ 𖹭₊ .tebakmakanan
┆𖢷 ׁ 𖹭₊ .tekateki
┆𖢷 ׁ 𖹭₊ .jawab 🅟
╰─╼𔕬─┈───┈───┈`

global.menuenc = `
╭╼ 🄴ncrypt 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Encrypt Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .enccustom
┆𖢷 ׁ 𖹭₊ .encinvis
┆𖢷 ׁ 𖹭₊ .encsiu
┆𖢷 ׁ 𖹭₊ .encstrong
┆𖢷 ׁ 𖹭₊ .encultra
┆𖢷 ׁ 𖹭₊ .enchard
┆𖢷 ׁ 𖹭₊ .enc
┆𖢷 ׁ 𖹭₊ .encryptcustom
┆𖢷 ׁ 𖹭₊ .encryptinvis
┆𖢷 ׁ 𖹭₊ .encryptsiu
┆𖢷 ׁ 𖹭₊ .encryptstrong
┆𖢷 ׁ 𖹭₊ .encryptultra
┆𖢷 ׁ 𖹭₊ .customenc
┆𖢷 ׁ 𖹭₊ .invisenc
┆𖢷 ׁ 𖹭₊ .siuenc
┆𖢷 ׁ 𖹭₊ .strongenc
┆𖢷 ׁ 𖹭₊ .ultraenc
┆𖢷 ׁ 𖹭₊ .custom-encrypt
┆𖢷 ׁ 𖹭₊ .invis-encrypt
┆𖢷 ׁ 𖹭₊ .siu-encrypt
┆𖢷 ׁ 𖹭₊ .strong-encrypt
┆𖢷 ׁ 𖹭₊ .ultra-encrypt
┆𖢷 ׁ 𖹭₊ .enc-custom
┆𖢷 ׁ 𖹭₊ .enc-invis
┆𖢷 ׁ 𖹭₊ .enc-siu
┆𖢷 ׁ 𖹭₊ .enc-strong
┆𖢷 ׁ 𖹭₊ .enc-ultra
┆𖢷 ׁ 𖹭₊ .enccustomjs
┆𖢷 ׁ 𖹭₊ .encinvisible
┆𖢷 ׁ 𖹭₊ .encryptinvisible
┆𖢷 ׁ 𖹭₊ .invisibleenc
┆𖢷 ׁ 𖹭₊ .invisible-encrypt
┆𖢷 ׁ 𖹭₊ .enc-invisible
┆𖢷 ׁ 𖹭₊ .eninvisiblejs
┆𖢷 ׁ 𖹭₊ .jsinvisenc
┆𖢷 ׁ 𖹭₊ .encjsinvis
┆𖢷 ׁ 𖹭₊ .encsiujs
┆𖢷 ׁ 𖹭₊ .jssiuenc
┆𖢷 ׁ 𖹭₊ .siujsen
┆𖢷 ׁ 𖹭₊ .encstrongjs
┆𖢷 ׁ 𖹭₊ .jsstrongenc
┆𖢷 ׁ 𖹭₊ .strongjsen
┆𖢷 ׁ 𖹭₊ .encultrajs
┆𖢷 ׁ 𖹭₊ .jsultraenc
┆𖢷 ׁ 𖹭₊ .ultrajsen
┆𖢷 ׁ 𖹭₊ .encryptcustomjs
┆𖢷 ׁ 𖹭₊ .customjsen
╰─╼𔕬─┈───┈───┈`

global.menustk = `
╭╼ 🅂ticker 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Sticker Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .stkbaik
┆𖢷 ׁ 𖹭₊ .stkcantik
┆𖢷 ׁ 𖹭₊ .stkganteng
┆𖢷 ׁ 𖹭₊ .stkhitam
┆𖢷 ׁ 𖹭₊ .stkmiskin
┆𖢷 ׁ 𖹭₊ .stkkaya
┆𖢷 ׁ 𖹭₊ .stkmarah
┆𖢷 ׁ 𖹭₊ .stksabar
┆𖢷 ׁ 𖹭₊ .stksakiti
┆𖢷 ׁ 𖹭₊ .stkkeren
┆𖢷 ׁ 𖹭₊ .stkmisterius
┆𖢷 ׁ 𖹭₊ .stksantai
┆𖢷 ׁ 𖹭₊ .stksombong
┆𖢷 ׁ 𖹭₊ .stklucu
┆𖢷 ׁ 𖹭₊ .stkgila
╰─╼𔕬─┈───┈───┈`

global.menurpg = `
╭╼ 🅁🄿🄶 🄶ame 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *RPG Game Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .daftar
┆𖢷 ׁ 𖹭₊ .profile
┆𖢷 ׁ 𖹭₊ .unreg
┆𖢷 ׁ 𖹭₊ .buatstreak
┆𖢷 ׁ 𖹭₊ .nyalainstreak
┆𖢷 ׁ 𖹭₊ .streak
┆𖢷 ׁ 𖹭₊ .topstreak
┆𖢷 ׁ 𖹭₊ .adopsipet
┆𖢷 ׁ 𖹭₊ .attack
┆𖢷 ׁ 𖹭₊ .begal
┆𖢷 ׁ 𖹭₊ .berkebun
┆𖢷 ׁ 𖹭₊ .buy
┆𖢷 ׁ 𖹭₊ .claim
┆𖢷 ׁ 𖹭₊ .craft
┆𖢷 ׁ 𖹭₊ .daily
┆𖢷 ׁ 𖹭₊ .dungeon
┆𖢷 ׁ 𖹭₊ .equip
┆𖢷 ׁ 𖹭₊ .flee
┆𖢷 ׁ 𖹭₊ .spacegame
┆𖢷 ׁ 𖹭₊ .foraging
┆𖢷 ׁ 𖹭₊ .infopet
┆𖢷 ׁ 𖹭₊ .inventory
┆𖢷 ׁ 𖹭₊ .item
┆𖢷 ׁ 𖹭₊ .jobkerja
┆𖢷 ׁ 𖹭₊ .judionline
┆𖢷 ׁ 𖹭₊ .kerja
┆𖢷 ׁ 𖹭₊ .leaderboardrpg
┆𖢷 ׁ 𖹭₊ .limit
┆𖢷 ׁ 𖹭₊ .maling
┆𖢷 ׁ 𖹭₊ .mancing
┆𖢷 ׁ 𖹭₊ .mancingstart
┆𖢷 ׁ 𖹭₊ .me
┆𖢷 ׁ 𖹭₊ .meramu
┆𖢷 ׁ 𖹭₊ .mining
┆𖢷 ׁ 𖹭₊ .ngaji
┆𖢷 ׁ 𖹭₊ .ngelonte
┆𖢷 ׁ 𖹭₊ .ngocok
┆𖢷 ׁ 𖹭₊ .ngojek
┆𖢷 ׁ 𖹭₊ .openbo
┆𖢷 ׁ 𖹭₊ .pvp
┆𖢷 ׁ 𖹭₊ .quest
┆𖢷 ׁ 𖹭₊ .rpgexplore
┆𖢷 ׁ 𖹭₊ .rpghelp
┆𖢷 ׁ 𖹭₊ .rpginv
┆𖢷 ׁ 𖹭₊ .rpgmove
┆𖢷 ׁ 𖹭₊ .rpgshop
┆𖢷 ׁ 𖹭₊ .rpgstart
┆𖢷 ׁ 𖹭₊ .rpgstats
┆𖢷 ׁ 𖹭₊ .sell
┆𖢷 ׁ 𖹭₊ .skill
┆𖢷 ׁ 𖹭₊ .tambang
┆𖢷 ׁ 𖹭₊ .toplevel
┆𖢷 ׁ 𖹭₊ .use
┆𖢷 ׁ 𖹭₊ .unequip
┆𖢷 ׁ 𖹭₊ .tfgold
┆𖢷 ׁ 𖹭₊ .cekgold
┆𖢷 ׁ 𖹭₊ .topgold
┆𖢷 ׁ 𖹭₊ .addgold
┆𖢷 ׁ 𖹭₊ .lb_rpg
┆𖢷 ׁ 𖹭₊ .besi
┆𖢷 ׁ 𖹭₊ .nikel
┆𖢷 ׁ 𖹭₊ .emas
┆𖢷 ׁ 𖹭₊ .berlian
╰─╼𔕬─┈───┈───┈`

global.menuephoto = `
╭╼ 🄴photo 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Ephoto Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .glitchtext
┆𖢷 ׁ 𖹭₊ .writetext
┆𖢷 ׁ 𖹭₊ .advancedglow
┆𖢷 ׁ 𖹭₊ .typographytext
┆𖢷 ׁ 𖹭₊ .pixelglitch
┆𖢷 ׁ 𖹭₊ .neonglitch
┆𖢷 ׁ 𖹭₊ .flagtext
┆𖢷 ׁ 𖹭₊ .flag3dtext
┆𖢷 ׁ 𖹭₊ .deletingtext
┆𖢷 ׁ 𖹭₊ .blackpinkstyle
┆𖢷 ׁ 𖹭₊ .glowingtext
┆𖢷 ׁ 𖹭₊ .underwatertext
┆𖢷 ׁ 𖹭₊ .logomaker
┆𖢷 ׁ 𖹭₊ .cartoonstyle
┆𖢷 ׁ 𖹭₊ .papercutstyle
┆𖢷 ׁ 𖹭₊ .watercolortext
┆𖢷 ׁ 𖹭₊ .effectclouds
┆𖢷 ׁ 𖹭₊ .blackpinklogo
┆𖢷 ׁ 𖹭₊ .gradienttext
┆𖢷 ׁ 𖹭₊ .summerbeach
┆𖢷 ׁ 𖹭₊ .luxurygold
┆𖢷 ׁ 𖹭₊ .multicoloredneon
┆𖢷 ׁ 𖹭₊ .sandsummer
┆𖢷 ׁ 𖹭₊ .galaxywallpaper
┆𖢷 ׁ 𖹭₊ .1917style
┆𖢷 ׁ 𖹭₊ .makingneon
┆𖢷 ׁ 𖹭₊ .royaltext
┆𖢷 ׁ 𖹭₊ .freecreate
┆𖢷 ׁ 𖹭₊ .galaxystyle
┆𖢷 ׁ 𖹭₊ .lighteffects
┆𖢷 ׁ 𖹭₊ .blackpink
┆𖢷 ׁ 𖹭₊ .dragonfire
┆𖢷 ׁ 𖹭₊ .eraser
┆𖢷 ׁ 𖹭₊ .galaxy
┆𖢷 ׁ 𖹭₊ .grafitti
┆𖢷 ׁ 𖹭₊ .horor
┆𖢷 ׁ 𖹭₊ .incandescent
┆𖢷 ׁ 𖹭₊ .nightstars
┆𖢷 ׁ 𖹭₊ .pig
┆𖢷 ׁ 𖹭₊ .pubg
┆𖢷 ׁ 𖹭₊ .sunlight
┆𖢷 ׁ 𖹭₊ .wood
┆𖢷 ׁ 𖹭₊ .ytgoldbutton
┆𖢷 ׁ 𖹭₊ .ytsilverbutton
╰─╼𔕬─┈───┈───┈`

global.menuislam = `
╭╼ 🄸slami 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Islami Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .asmaulhusna
┆𖢷 ׁ 𖹭₊ .audiosurah
┆𖢷 ׁ 𖹭₊ .ayatkursi
┆𖢷 ׁ 𖹭₊ .bacaansholat
┆𖢷 ׁ 𖹭₊ .doa
┆𖢷 ׁ 𖹭₊ .doaharian
┆𖢷 ׁ 𖹭₊ .hadits
┆𖢷 ׁ 𖹭₊ .islamic
┆𖢷 ׁ 𖹭₊ .jadwalsholat
┆𖢷 ׁ 𖹭₊ .kisahnabi
┆𖢷 ׁ 𖹭₊ .niatsholat
┆𖢷 ׁ 𖹭₊ .quotesislami
┆𖢷 ׁ 𖹭₊ .wirid
╰─╼𔕬─┈───┈───┈`

global.menucecan = `
╭╼ 🄲ecan & 🄲ogan 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Cecan & Cogan Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .cecan
┆𖢷 ׁ 𖹭₊ .cecanchina
┆𖢷 ׁ 𖹭₊ .cecanhijaber
┆𖢷 ׁ 𖹭₊ .cecanindonesia
┆𖢷 ׁ 𖹭₊ .cecanjapan
┆𖢷 ׁ 𖹭₊ .cecanjeni
┆𖢷 ׁ 𖹭₊ .cecanjiso
┆𖢷 ׁ 𖹭₊ .cecankorea
┆𖢷 ׁ 𖹭₊ .cecanmalaysia
┆𖢷 ׁ 𖹭₊ .cecanjustinaxie
┆𖢷 ׁ 𖹭₊ .cecanrose
┆𖢷 ׁ 𖹭₊ .cecanryujin
┆𖢷 ׁ 𖹭₊ .cecanthailand
┆𖢷 ׁ 𖹭₊ .cecanvietnam
┆𖢷 ׁ 𖹭₊ .cogan
╰─╼𔕬─┈───┈───┈`

global.menurandom = `
╭╼ 🅁andom 🄸mage 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Random Image Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .randommeme
┆𖢷 ׁ 𖹭₊ .randomaesthetic
┆𖢷 ׁ 𖹭₊ .randomanjing
┆𖢷 ׁ 𖹭₊ .randomantiwork
┆𖢷 ׁ 𖹭₊ .randomblackpink
┆𖢷 ׁ 𖹭₊ .randomboneka
┆𖢷 ׁ 𖹭₊ .randomcecan
┆𖢷 ׁ 𖹭₊ .randomcogan
┆𖢷 ׁ 𖹭₊ .randomcosplay
┆𖢷 ׁ 𖹭₊ .randomdadu
┆𖢷 ׁ 𖹭₊ .randomhekel
┆𖢷 ׁ 𖹭₊ .randomjustina
┆𖢷 ׁ 𖹭₊ .randomkayes
┆𖢷 ׁ 𖹭₊ .randomkpop
┆𖢷 ׁ 𖹭₊ .randomkucing
┆𖢷 ׁ 𖹭₊ .randommobil
┆𖢷 ׁ 𖹭₊ .randommotor
┆𖢷 ׁ 𖹭₊ .randomnotnot
┆𖢷 ׁ 𖹭₊ .randomppcp
┆𖢷 ׁ 𖹭₊ .randomprofile
┆𖢷 ׁ 𖹭₊ .randompubg
┆𖢷 ׁ 𖹭₊ .randomquotenime
┆𖢷 ׁ 𖹭₊ .randomrose
┆𖢷 ׁ 𖹭₊ .randomryujin
┆𖢷 ׁ 𖹭₊ .randomwallhp
┆𖢷 ׁ 𖹭₊ .randomwallml
╰─╼𔕬─┈───┈───┈`

global.menupanel = `
╭╼ 🄿anel 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Panel Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .1gb
┆𖢷 ׁ 𖹭₊ .2gb
┆𖢷 ׁ 𖹭₊ .3gb
┆𖢷 ׁ 𖹭₊ .4gb
┆𖢷 ׁ 𖹭₊ .5gb
┆𖢷 ׁ 𖹭₊ .6gb
┆𖢷 ׁ 𖹭₊ .7gb
┆𖢷 ׁ 𖹭₊ .unli
┆𖢷 ׁ 𖹭₊ .mypanel
┆𖢷 ׁ 𖹭₊ .listpanel
┆𖢷 ׁ 𖹭₊ .listuser
┆𖢷 ׁ 𖹭₊ .renewserver
┆𖢷 ׁ 𖹭₊ .notif
┆𖢷 ׁ 𖹭₊ .delsrv
┆𖢷 ׁ 𖹭₊ .deluser
┆𖢷 ׁ 𖹭₊ .setpanel 🅞
┆𖢷 ׁ 𖹭₊ .installpanel 🅞
┆𖢷 ׁ 𖹭₊ .addreseller
┆𖢷 ׁ 𖹭₊ .cekres
┆𖢷 ׁ 𖹭₊ .delreseller 🅞
┆𖢷 ׁ 𖹭₊ .listreseller 🅞
┆𖢷 ׁ 𖹭₊ .cadp
╰─╼𔕬─┈───┈───┈`

global.menunsfw = `
╭╼ 🄽🅂🄵🅆 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *NSFW Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .nsfw 🅟
┆𖢷 ׁ 𖹭₊ .nsfwahegao 🅟
┆𖢷 ׁ 𖹭₊ .nsfwass 🅟
┆𖢷 ׁ 𖹭₊ .nsfwbdsm 🅟
┆𖢷 ׁ 𖹭₊ .nsfwblowjob 🅟
┆𖢷 ׁ 𖹭₊ .nsfwcuckold 🅟
┆𖢷 ׁ 𖹭₊ .nsfwcum 🅟
┆𖢷 ׁ 𖹭₊ .nsfweba 🅟
┆𖢷 ׁ 𖹭₊ .nsfwero 🅟
┆𖢷 ׁ 𖹭₊ .nsfwfemdom 🅟
┆𖢷 ׁ 𖹭₊ .nsfwfoot 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgangbang 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgay 🅟
┆𖢷 ׁ 𖹭₊ .nsfwgifs 🅟
┆𖢷 ׁ 𖹭₊ .nsfwglasses 🅟
┆𖢷 ׁ 𖹭₊ .nsfwhentai 🅟
┆𖢷 ׁ 𖹭₊ .nsfwjahy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwkasedaiki 🅟
┆𖢷 ׁ 𖹭₊ .nsfwloli 🅟
┆𖢷 ׁ 𖹭₊ .nsfwmanga 🅟
┆𖢷 ׁ 𖹭₊ .nsfwmasturbation 🅟
┆𖢷 ׁ 𖹭₊ .nsfwneko 🅟
┆𖢷 ׁ 𖹭₊ .nsfwneko2 🅟
┆𖢷 ׁ 𖹭₊ .nsfwopai 🅟
┆𖢷 ׁ 𖹭₊ .nsfworgy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwpanties 🅟
┆𖢷 ׁ 𖹭₊ .nsfwpussy 🅟
┆𖢷 ׁ 𖹭₊ .nsfwtentacles 🅟
┆𖢷 ׁ 𖹭₊ .nsfwthighs 🅟
┆𖢷 ׁ 𖹭₊ .nsfwyuri 🅟
┆𖢷 ׁ 𖹭₊ .nsfwzettai 🅟
╰─╼𔕬─┈───┈───┈`

global.menuanime = `
╭╼ 🄰nime 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Anime Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .animeakira
┆𖢷 ׁ 𖹭₊ .animeasuna
┆𖢷 ׁ 𖹭₊ .animeeba
┆𖢷 ׁ 𖹭₊ .animeelaina
┆𖢷 ׁ 𖹭₊ .animeemilia
┆𖢷 ׁ 𖹭₊ .animegremory
┆𖢷 ׁ 𖹭₊ .animehinata
┆𖢷 ׁ 𖹭₊ .animehusbu
┆𖢷 ׁ 𖹭₊ .animeisuzu
┆𖢷 ׁ 𖹭₊ .animeitori
┆𖢷 ׁ 𖹭₊ .animekagura
┆𖢷 ׁ 𖹭₊ .animekanna
┆𖢷 ׁ 𖹭₊ .animemegumin
┆𖢷 ׁ 𖹭₊ .animemiku
┆𖢷 ׁ 𖹭₊ .animenezuko
┆𖢷 ׁ 𖹭₊ .animensfwloli 🅟
┆𖢷 ׁ 𖹭₊ .animepokemon
┆𖢷 ׁ 𖹭₊ .animerem
┆𖢷 ׁ 𖹭₊ .animeryuko
┆𖢷 ׁ 𖹭₊ .animeshina
┆𖢷 ׁ 𖹭₊ .animeshinka
┆𖢷 ׁ 𖹭₊ .animeshota
┆𖢷 ׁ 𖹭₊ .animetejina
┆𖢷 ׁ 𖹭₊ .animetoukachan
┆𖢷 ׁ 𖹭₊ .animewaifu
┆𖢷 ׁ 𖹭₊ .animeyotsuba
┆𖢷 ׁ 𖹭₊ .animeyuli
┆𖢷 ׁ 𖹭₊ .animeyumeko
┆𖢷 ׁ 𖹭₊ .animezero
╰─╼𔕬─┈───┈───┈`

global.potoanime = `
╭╼ 🄰nime/🅃hema 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Anime/Theme Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .akiyama
┆𖢷 ׁ 𖹭₊ .ana
┆𖢷 ׁ 𖹭₊ .art
┆𖢷 ׁ 𖹭₊ .asuna
┆𖢷 ׁ 𖹭₊ .ayuzawa
┆𖢷 ׁ 𖹭₊ .boruto
┆𖢷 ׁ 𖹭₊ .bts
┆𖢷 ׁ 𖹭₊ .cartoon
┆𖢷 ׁ 𖹭₊ .chiho
┆𖢷 ׁ 𖹭₊ .chitoge
┆𖢷 ׁ 𖹭₊ .cosplay
┆𖢷 ׁ 𖹭₊ .cosplayloli
┆𖢷 ׁ 𖹭₊ .cosplaysagiri
┆𖢷 ׁ 𖹭₊ .cyber
┆𖢷 ׁ 𖹭₊ .deidara
┆𖢷 ׁ 𖹭₊ .doraemon
┆𖢷 ׁ 𖹭₊ .forcexyz
┆𖢷 ׁ 𖹭₊ .emilia
┆𖢷 ׁ 𖹭₊ .erza
┆𖢷 ׁ 𖹭₊ .exo
┆𖢷 ׁ 𖹭₊ .gamewallpaper
┆𖢷 ׁ 𖹭₊ .gremory
┆𖢷 ׁ 𖹭₊ .hacker
┆𖢷 ׁ 𖹭₊ .hestia
┆𖢷 ׁ 𖹭₊ .hinata
┆𖢷 ׁ 𖹭₊ .husbu
┆𖢷 ׁ 𖹭₊ .inori
┆𖢷 ׁ 𖹭₊ .islamic
┆𖢷 ׁ 𖹭₊ .isuzu
┆𖢷 ׁ 𖹭₊ .itachi
┆𖢷 ׁ 𖹭₊ .itori
┆𖢷 ׁ 𖹭₊ .jennie
┆𖢷 ׁ 𖹭₊ .jiso
┆𖢷 ׁ 𖹭₊ .justina
┆𖢷 ׁ 𖹭₊ .kaga
┆𖢷 ׁ 𖹭₊ .kagura
┆𖢷 ׁ 𖹭₊ .kakasih
┆𖢷 ׁ 𖹭₊ .kaori
┆𖢷 ׁ 𖹭₊ .keneki
┆𖢷 ׁ 𖹭₊ .kotori
┆𖢷 ׁ 𖹭₊ .kurumi
┆𖢷 ׁ 𖹭₊ .lisa
┆𖢷 ׁ 𖹭₊ .madara
┆𖢷 ׁ 𖹭₊ .megumin
┆𖢷 ׁ 𖹭₊ .mikasa
┆𖢷 ׁ 𖹭₊ .mikey
┆𖢷 ׁ 𖹭₊ .miku
┆𖢷 ׁ 𖹭₊ .minato
┆𖢷 ׁ 𖹭₊ .mountain
┆𖢷 ׁ 𖹭₊ .naruto
┆𖢷 ׁ 𖹭₊ .neko2
┆𖢷 ׁ 𖹭₊ .nekonime
┆𖢷 ׁ 𖹭₊ .nezuko
┆𖢷 ׁ 𖹭₊ .onepiece
┆𖢷 ׁ 𖹭₊ .pentol
┆𖢷 ׁ 𖹭₊ .pokemon
┆𖢷 ׁ 𖹭₊ .programming
┆𖢷 ׁ 𖹭₊ .randomnime
┆𖢷 ׁ 𖹭₊ .randomnime2
┆𖢷 ׁ 𖹭₊ .rize
┆𖢷 ׁ 𖹭₊ .rose
┆𖢷 ׁ 𖹭₊ .sagiri
┆𖢷 ׁ 𖹭₊ .sakura
┆𖢷 ׁ 𖹭₊ .sasuke
┆𖢷 ׁ 𖹭₊ .satanic
┆𖢷 ׁ 𖹭₊ .shina
┆𖢷 ׁ 𖹭₊ .shinka
┆𖢷 ׁ 𖹭₊ .shinomiya
┆𖢷 ׁ 𖹭₊ .shizuka
┆𖢷 ׁ 𖹭₊ .shota
┆𖢷 ׁ 𖹭₊ .shortquote
┆𖢷 ׁ 𖹭₊ .space
┆𖢷 ׁ 𖹭₊ .technology
┆𖢷 ׁ 𖹭₊ .tejina
┆𖢷 ׁ 𖹭₊ .toukachan
┆𖢷 ׁ 𖹭₊ .tsunade
┆𖢷 ׁ 𖹭₊ .yotsuba
┆𖢷 ׁ 𖹭₊ .yuki
┆𖢷 ׁ 𖹭₊ .yulibocil
┆𖢷 ׁ 𖹭₊ .yumeko
╰─╼𔕬─┈───┈───┈`

global.menustore = `
╭╼ 🅂tore 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Store Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .list
┆𖢷 ׁ 𖹭₊ .setlist 🅐
┆𖢷 ׁ 𖹭₊ .addlist 🅐
┆𖢷 ׁ 𖹭₊ .dellist 🅐
┆𖢷 ׁ 𖹭₊ .clearlist 🅐
┆𖢷 ׁ 𖹭₊ .setpay 🅐
┆𖢷 ׁ 𖹭₊ .delpay 🅐
┆𖢷 ׁ 𖹭₊ .listpay
┆𖢷 ׁ 𖹭₊ .setdone 🅐
┆𖢷 ׁ 𖹭₊ .setproses 🅐
┆𖢷 ׁ 𖹭₊ .done 🅐
┆𖢷 ׁ 𖹭₊ .proses 🅐
┆𖢷 ׁ 𖹭₊ .testimoni
┆𖢷 ׁ 𖹭₊ .buyprem
┆𖢷 ׁ 𖹭₊ .buyapkprem
┆𖢷 ׁ 𖹭₊ .buysewagc
┆𖢷 ׁ 𖹭₊ .done 🅐
┆𖢷 ׁ 𖹭₊ .jpm 🅞
┆𖢷 ׁ 𖹭₊ .jpm2 🅞
┆𖢷 ׁ 𖹭₊ .jpmtesti 🅞
┆𖢷 ׁ 𖹭₊ .payment
┆𖢷 ׁ 𖹭₊ .proses 🅐
┆𖢷 ׁ 𖹭₊ .pushkontak 🅞
┆𖢷 ׁ 𖹭₊ .pushkontak2 🅞
┆𖢷 ׁ 𖹭₊ .sendtesti
┆𖢷 ׁ 𖹭₊ .addreselleram 🅞
┆𖢷 ׁ 𖹭₊ .delreselleram 🅞
┆𖢷 ׁ 𖹭₊ .listreselleram 🅞
┆𖢷 ׁ 𖹭₊ .amprem
╰─╼𔕬─┈───┈───┈`

global.menugroup = `
╭╼ 🄶roup 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Group Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .autolevel
┆𖢷 ׁ 𖹭₊ .setclosetime 🅐
┆𖢷 ׁ 𖹭₊ .setopentime 🅐
┆𖢷 ׁ 𖹭₊ .cekjadwal
┆𖢷 ׁ 𖹭₊ .resetjadwal 🅐
┆𖢷 ׁ 𖹭₊ .autosholat 🅐
┆𖢷 ׁ 𖹭₊ .addbadword
┆𖢷 ׁ 𖹭₊ .listbadword
┆𖢷 ׁ 𖹭₊ .delbadword
┆𖢷 ׁ 𖹭₊ .banfitur 🅐
┆𖢷 ׁ 𖹭₊ .intro
┆𖢷 ׁ 𖹭₊ .setintro 🅐
┆𖢷 ׁ 𖹭₊ .closetime 🅐
┆𖢷 ׁ 𖹭₊ .opentime 🅐
┆𖢷 ׁ 𖹭₊ .warn 🅐
┆𖢷 ׁ 𖹭₊ .listwarn
┆𖢷 ׁ 𖹭₊ .delwarn 🅐
┆𖢷 ׁ 𖹭₊ .infowarn
┆𖢷 ׁ 𖹭₊ .resetwarn 🅐
┆𖢷 ׁ 𖹭₊ .infogrup
┆𖢷 ׁ 𖹭₊ .hidetagpoll 🅐
┆𖢷 ׁ 𖹭₊ .gcsider 🅐
┆𖢷 ׁ 𖹭₊ .sidercek
┆𖢷 ׁ 𖹭₊ .siderkick
┆𖢷 ׁ 𖹭₊ .infouser
┆𖢷 ׁ 𖹭₊ .setnamagc 🅐
┆𖢷 ׁ 𖹭₊ .setppgc 🅐
┆𖢷 ׁ 𖹭₊ .schedule 🅐
┆𖢷 ׁ 𖹭₊ .autoabsen 🅐
┆𖢷 ׁ 𖹭₊ .setabsen 🅐
┆𖢷 ׁ 𖹭₊ .tagadmin 🅐
┆𖢷 ׁ 𖹭₊ .acc 🅐
┆𖢷 ׁ 𖹭₊ .tolakacc 🅐
┆𖢷 ׁ 𖹭₊ .swgc 🅐
┆𖢷 ׁ 𖹭₊ .swgcall 🅞
┆𖢷 ׁ 𖹭₊ .totalchat
┆𖢷 ׁ 𖹭₊ .resettotalchat 🅐
┆𖢷 ׁ 𖹭₊ .setultah
┆𖢷 ׁ 𖹭₊ .ultah
┆𖢷 ׁ 𖹭₊ .delultah
┆𖢷 ׁ 𖹭₊ .listultah
┆𖢷 ׁ 𖹭₊ .afk
┆𖢷 ׁ 𖹭₊ .onlyadmin 🅐
┆𖢷 ׁ 𖹭₊ .add
┆𖢷 ׁ 𖹭₊ .cekidch
┆𖢷 ׁ 𖹭₊ .cekidgc
┆𖢷 ׁ 𖹭₊ .close
┆𖢷 ׁ 𖹭₊ .setclose 🅐
┆𖢷 ׁ 𖹭₊ .setopen 🅐
┆𖢷 ׁ 𖹭₊ .demote
┆𖢷 ׁ 𖹭₊ .hidetag 🅐
┆𖢷 ׁ 𖹭₊ .kick
┆𖢷 ׁ 𖹭₊ .kudeta 🅞
┆𖢷 ׁ 𖹭₊ .leaderboard
┆𖢷 ׁ 𖹭₊ .leave 🅞
┆𖢷 ׁ 𖹭₊ .linkgc
┆𖢷 ׁ 𖹭₊ .off 🅐
┆𖢷 ׁ 𖹭₊ .on
┆𖢷 ׁ 𖹭₊ .open 🅐
┆𖢷 ׁ 𖹭₊ .promote 🅐
┆𖢷 ׁ 𖹭₊ .resetlinkgc 🅞
┆𖢷 ׁ 𖹭₊ .setleft 🅐
┆𖢷 ׁ 𖹭₊ .setwelcome 🅐
┆𖢷 ׁ 𖹭₊ .testwelcome 🅐
┆𖢷 ׁ 𖹭₊ .testleft 🅐
┆𖢷 ׁ 𖹭₊ .tagall 🅐
╰─╼𔕬─┈───┈───┈`

global.menuowner = `
╭╼ 🄾wner 🄼enu
 ╰╼ ׅ ֹ𔖰᷼𔖮 *Owner Menu*
╭╼─┈───┈──⏣╼╯
┆𖢷 ׁ 𖹭₊ .addrespon 🅞
┆𖢷 ׁ 𖹭₊ .delrespon 🅞
┆𖢷 ׁ 𖹭₊ .clearrespon 🅞
┆𖢷 ׁ 𖹭₊ .listrespon 🅞
┆𖢷 ׁ 𖹭₊ .autocorrect 🅞
┆𖢷 ׁ 𖹭₊ .setrestart 🅞
┆𖢷 ׁ 𖹭₊ .setlabel 🅞
┆𖢷 ׁ 𖹭₊ .addpremgc
┆𖢷 ׁ 𖹭₊ .delpremgc
┆𖢷 ׁ 𖹭₊ .mutegc 🅞
┆𖢷 ׁ 𖹭₊ .unmutegc 🅞
┆𖢷 ׁ 𖹭₊ .sistemsewa 🅞
┆𖢷 ׁ 𖹭₊ .autoreactsw 🅞
┆𖢷 ׁ 𖹭₊ .autosambut 🅞
┆𖢷 ׁ 𖹭₊ .addprefix
┆𖢷 ׁ 𖹭₊ .listprefix
┆𖢷 ׁ 𖹭₊ .sefprefix
┆𖢷 ׁ 𖹭₊ .renamebot 🅞
┆𖢷 ׁ 𖹭₊ .setaudiomenu 🅞
┆𖢷 ׁ 𖹭₊ .setimage 🅞
┆𖢷 ׁ 𖹭₊ .culikmember 🅞
┆𖢷 ׁ 𖹭₊ .setdaftar
┆𖢷 ׁ 𖹭₊ .setmenu 🅞
┆𖢷 ׁ 𖹭₊ .stikercmd 🅞
┆𖢷 ׁ 𖹭₊ .delstikercmd 🅞
┆𖢷 ׁ 𖹭₊ .addaksesprem
┆𖢷 ׁ 𖹭₊ .delaksesprem 🅞
┆𖢷 ׁ 𖹭₊ .listaksesprem
┆𖢷 ׁ 𖹭₊ .onlyprem 🅐
┆𖢷 ׁ 𖹭₊ .addcase
┆𖢷 ׁ 𖹭₊ .addlimit 🅞
┆𖢷 ׁ 𖹭₊ .addlimitall 🅞
┆𖢷 ׁ 𖹭₊ .addowner
┆𖢷 ׁ 𖹭₊ .addprem
┆𖢷 ׁ 𖹭₊ .addsewagc
┆𖢷 ׁ 𖹭₊ .listsewagc
┆𖢷 ׁ 𖹭₊ .delsewagc 🅞
┆𖢷 ׁ 𖹭₊ .ceksewagc
┆𖢷 ׁ 𖹭₊ .renewsewagc
┆𖢷 ׁ 𖹭₊ .antibot 🅐
┆𖢷 ׁ 𖹭₊ .autobackup
┆𖢷 ׁ 𖹭₊ .autoread
┆𖢷 ׁ 𖹭₊ .autoreadsw
┆𖢷 ׁ 𖹭₊ .autotyping
┆𖢷 ׁ 𖹭₊ .backup
┆𖢷 ׁ 𖹭₊ .blacklist 🅞
┆𖢷 ׁ 𖹭₊ .cekprem
┆𖢷 ׁ 𖹭₊ .clearchat
┆𖢷 ׁ 𖹭₊ .clearprem 🅞
┆𖢷 ׁ 𖹭₊ .creategc
┆𖢷 ׁ 𖹭₊ .delcase 🅞
┆𖢷 ׁ 𖹭₊ .dellimit 🅞
┆𖢷 ׁ 𖹭₊ .delowner
┆𖢷 ׁ 𖹭₊ .delprem 🅞
┆𖢷 ׁ 𖹭₊ .getcase 🅞
┆𖢷 ׁ 𖹭₊ .getsc
┆𖢷 ׁ 𖹭₊ .joinch
┆𖢷 ׁ 𖹭₊ .joingc
┆𖢷 ׁ 𖹭₊ .listcase 🅞
┆𖢷 ׁ 𖹭₊ .listgc
┆𖢷 ׁ 𖹭₊ .listowner
┆𖢷 ׁ 𖹭₊ .listprem
┆𖢷 ׁ 𖹭₊ .pay2
┆𖢷 ׁ 𖹭₊ .resetdb
┆𖢷 ׁ 𖹭₊ .resetlimitall 🅞
┆𖢷 ׁ 𖹭₊ .restartbot
┆𖢷 ׁ 𖹭₊ .savekontak 🅞
┆𖢷 ׁ 𖹭₊ .self
┆𖢷 ׁ 𖹭₊ .setlimit 🅞
┆𖢷 ׁ 𖹭₊ .setppbot 🅞
┆𖢷 ׁ 𖹭₊ .unblacklist 🅞
┆𖢷 ׁ 𖹭₊ .upchannel
┆𖢷 ׁ 𖹭₊ .upchannel2
╰─╼𔕬─┈───┈───┈`

global.allmenu = `${global.menusticker} 
${global.menuprem}
${global.menutools}
${global.menumaker}
${global.menuprimbon}
${global.menufun}
${global.menudownload}
${global.menuai}
${global.menusearch}
${global.menugame}
${global.menuenc}
${global.menustk}
${global.menurpg}
${global.menuephoto}
${global.menuislam}
${global.menucecan}
${global.menuasupan}
${global.menurandom}
${global.menupanel}
${global.menunsfw}
${global.menuanime}
${global.potoanime}
${global.menustore}
${global.menugroup}
${global.menuowner}`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});