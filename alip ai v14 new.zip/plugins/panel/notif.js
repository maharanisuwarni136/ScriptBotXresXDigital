const {
  ensureDB,
  loadPanelDB,
  savePanelDB,
  normalizePhone,
  isResellerFn,
  daysLeftFromExpiry,
  checkServerExists,
  suspendServer,
  hasSent,
  markSent,
  buildReminderText,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  if (!isCreator && !isReseller) {
    return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
  }

  try {
    const thresholds = [7, 5, 3, 1, 0];
    const panelDB = loadPanelDB();

    const targets = isCreator
      ? panelDB
      : panelDB.filter((p) => String(p.reseller || "") === String(m.sender));

    if (targets.length === 0) return Reply("Tidak ditemukan data panel terkait pada akun Anda.");

    await m.reply("Sedang memindai data dan mengirimkan pengingat...");

    let sentCount = 0;
    let suspendedCount = 0;

    for (const p of targets) {
      const serverId = p.serverId;
      const owner = normalizePhone(p.owner || "");
      if (!serverId || !owner) continue;

      const dLeft = daysLeftFromExpiry(p.expiresAt);

      let key = null;
      if (dLeft <= 0) key = 0;
      else if (thresholds.includes(dLeft)) key = dLeft;
      if (key === null) continue;

      if (hasSent(serverId, key)) continue;

      const jid = `${owner}@s.whatsapp.net`;
      const mentionTag = `@${owner}`;

      if (key === 0) {
        const exists = await checkServerExists(serverId);
        if (exists && !p.suspended) {
          const ok = await suspendServer(serverId);
          if (ok) {
            p.suspended = true;
            suspendedCount++;
          }
        } else if (!exists) {
          p.suspended = true;
        }
      }

      const teks = buildReminderText({
        daysLeft: dLeft <= 0 ? 0 : dLeft,
        serverName: p.name || "Unnamed",
        serverId: serverId,
        mentionTag: mentionTag,
      });

      try {
        await alip.sendMessage(jid, { text: teks, mentions: [jid] });
        markSent(serverId, key);
        sentCount++;
      } catch (e) {
        console.error("Gagal mengirim pengingat:", e);
      }
    }

    savePanelDB(panelDB);

    return Reply(`Proses pengingat selesai.\nPesan terkirim: ${sentCount}\nServer ditangguhkan otomatis: ${suspendedCount}`);
  } catch (e) {
    console.error("Notif Command Error:", e);
    return Reply("Terjadi kesalahan saat memproses notifikasi.");
  }
};

handler.command = ["notif"];

module.exports = handler;
