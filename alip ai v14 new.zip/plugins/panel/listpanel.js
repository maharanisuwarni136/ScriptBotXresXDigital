const {
  ensureDB,
  loadPanelDB,
  isResellerFn,
  daysLeftFromExpiry,
  apiGET,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  try {
    await m.reply("Sedang memuat data operasional server...");

    const res = await apiGET("/servers");
    if (!res.ok) return Reply(`Sinkronisasi data dengan server utama gagal (Kode: ${res.status}).`);

    const data = await res.json();
    if (!data.data || data.data.length === 0) return Reply("Tidak ditemukan riwayat layanan yang sedang berjalan.");

    const allPanels = loadPanelDB();

    const filtered = !isCreator && isReseller
      ? data.data.filter((s) => {
          const p = allPanels.find((x) => String(x.serverId) === String(s.attributes.id));
          return p && p.reseller === m.sender;
        })
      : data.data;

    if (filtered.length === 0) return Reply("Anda belum memiliki server yang terdaftar di bawah pengawasan Anda.");

    let listText = `╭─⬣「 REKAPITULASI SERVER 」⬣\n│\n`;
    let serverCount = 0, activeInDB = 0, expiredInDB = 0;

    for (const s of filtered) {
      const serverId = s.attributes.id;
      const serverName = s.attributes.name;
      const serverUser = s.attributes.user;

      const panelInfo = allPanels.find((p) => String(p.serverId) === String(serverId));
      const dLeft = panelInfo ? daysLeftFromExpiry(panelInfo.expiresAt) : 0;
      const status = panelInfo ? (dLeft > 0 ? "🟢" : "🔴") : "⚪";

      listText += `├─ ${++serverCount}. ${serverName}\n`;
      listText += `│  ├─ 🆔 ID Server: ${serverId}\n`;
      listText += `│  ├─ 👤 ID Pengguna: ${serverUser}\n`;

      if (panelInfo) {
        listText += `│  ├─ 👤 Pemilik: ${panelInfo.owner || "-"}\n`;
        listText += `│  ├─ 📅 Batas Waktu: ${panelInfo.expiresAt ? new Date(Number(panelInfo.expiresAt)).toLocaleDateString("id-ID") : "-"}\n`;
        listText += `│  └─ 🔋 Status Saat Ini: ${status} (${dLeft} hari)${panelInfo.suspended ? " / Ditangguhkan" : ""}\n`;
        if (dLeft > 0) activeInDB++;
        else expiredInDB++;
      } else {
        listText += `│  └─ ⚠️ Data tidak tersinkronisasi dengan database lokal\n`;
      }
    }

    const notInServer = allPanels.filter((p) => !(data.data || []).some((s) => String(s.attributes.id) === String(p.serverId))).length;

    listText += `│\n├─ Ringkasan Sistem\n`;
    listText += `│  ├─ 🖥️ Total Ditampilkan: ${serverCount}\n`;
    listText += `│  ├─ ✅ Layanan Aktif: ${activeInDB}\n`;
    listText += `│  ├─ 🔴 Layanan Kadaluarsa: ${expiredInDB}\n`;
    listText += `│  └─ 🗑️ Anomali Data: ${notInServer}\n`;
    listText += `╰─⬣`;

    return Reply(listText);
  } catch (e) {
    console.error("ListPanel Error:", e);
    return Reply("Pengambilan rekapitulasi server gagal dilakukan.");
  }
};

handler.command = ["listpanel"];

module.exports = handler;
