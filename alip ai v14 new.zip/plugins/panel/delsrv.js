const {
  ensureDB,
  loadPanelDB,
  savePanelDB,
  loadUsersDB,
  saveUsersDB,
  normalizePhone,
  isResellerFn,
  fallbackPrefix,
  checkServerExists,
  deleteServer,
  deleteUser,
  clearNotifState,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);
  const cmd = String(command || "").toLowerCase();

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  if (cmd === "delsrv") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }
    const serverId = Number(String(text || "").trim());
    if (!serverId) return Reply(`Format penggunaan: ${fallbackPrefix}delsrv <ID Server>`);

    const db = loadPanelDB();
    const panel = db.find((p) => String(p.serverId) === String(serverId));

    if (panel && !isCreator && panel.reseller !== m.sender) {
      return Reply("Maaf, Anda tidak memiliki akses untuk menghapus server ini.");
    }

    await m.reply("Sedang memproses penghapusan server...");

    const exists = await checkServerExists(serverId);
    if (exists) {
      const ok = await deleteServer(serverId);
      if (!ok) return Reply("Penghapusan server gagal. Silakan periksa kembali konfigurasi API atau hak akses.");
    }

    const newDB = db.filter((p) => String(p.serverId) !== String(serverId));
    savePanelDB(newDB);
    clearNotifState(serverId);

    return Reply(`Server dengan ID ${serverId} beserta datanya berhasil dihapus.`);
  }

  if (cmd === "deluser") {
    if (!isCreator && !isReseller) {
      return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
    }

    if (!text) {
      return Reply(`Format penggunaan:\n${fallbackPrefix}deluser 628xxxx\natau\n${fallbackPrefix}deluser username`);
    }

    const key = String(text).trim().toLowerCase();
    const usersDB = loadUsersDB();
    const panelsDB = loadPanelDB();

    let userEntry = null;
    if (/^\d+$/.test(key)) {
      const phone = normalizePhone(key);
      userEntry = usersDB.find((u) => String(u.phone) === String(phone));
    } else {
      userEntry = usersDB.find((u) => String(u.username || "").toLowerCase() === key);
    }

    if (!userEntry) return Reply("Data pengguna tidak ditemukan.");

    const ownerPhone = String(userEntry.phone);
    const userServers = panelsDB.filter((p) => String(p.owner || "") === ownerPhone);

    if (!isCreator) {
      const ownedByReseller = userServers.some((p) => p.reseller === m.sender);
      if (!ownedByReseller) return Reply("Maaf, Anda tidak memiliki wewenang atas pengguna ini.");
    }

    await m.reply(`Sedang memproses penghapusan akun pengguna beserta ${userServers.length} server miliknya...`);

    let delOk = 0, delFail = 0;
    for (const s of userServers) {
      const sid = s.serverId;
      const exists = await checkServerExists(sid);
      if (exists) {
        const ok = await deleteServer(sid);
        if (ok) {
          delOk++;
          clearNotifState(sid);
        } else {
          delFail++;
        }
      } else {
        delOk++;
        clearNotifState(sid);
      }
    }

    const newPanels = panelsDB.filter((p) => String(p.owner || "") !== ownerPhone);
    savePanelDB(newPanels);

    const okUser = await deleteUser(userEntry.userId);

    const newUsers = usersDB.filter((u) => String(u.phone) !== String(ownerPhone));
    saveUsersDB(newUsers);

    return Reply(
      `Proses selesai.\n` +
      `Pengguna: ${userEntry.username} (${ownerPhone})\n` +
      `Server terhapus: ${delOk}\n` +
      `Server gagal dihapus: ${delFail}\n` +
      `Status penghapusan akun: ${okUser ? "Berhasil" : "Gagal"}`
    );
  }
};

handler.command = ["delsrv", "deluser"];

module.exports = handler;
