const crypto = require("crypto");
const {
  ensureDB,
  loadUsersDB,
  saveUsersDB,
  upsertPanel,
  fallbackPrefix,
  normalizePhone,
  toServerName,
  isResellerFn,
  DAY_MS,
  apiGET,
  apiPOST,
  getServerAllocations,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);
  const cmd = String(command || "").toLowerCase();

  const createCommands = ["1gb", "2gb", "3gb", "4gb", "5gb", "6gb", "7gb", "unlimited", "unli"];
  const specs = {
    "1gb": { ram: 1024, disk: 5120, cpu: 100 },
    "2gb": { ram: 2048, disk: 10240, cpu: 150 },
    "3gb": { ram: 3072, disk: 15360, cpu: 200 },
    "4gb": { ram: 4096, disk: 20480, cpu: 250 },
    "5gb": { ram: 5120, disk: 25600, cpu: 300 },
    "6gb": { ram: 6144, disk: 30720, cpu: 350 },
    "7gb": { ram: 7168, disk: 35840, cpu: 400 },
    unlimited: { ram: 0, disk: 51200, cpu: 0 },
    unli: { ram: 0, disk: 51200, cpu: 0 },
  };

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  if (!isCreator && !isReseller) {
    return Reply("Maaf, akses ditolak. Fitur ini hanya dapat digunakan oleh Reseller atau Owner.");
  }

  if (!text || !text.includes("|")) {
    return Reply(`Format salah. Contoh penggunaan:\n${fallbackPrefix}${cmd} username|628xxx|30`);
  }

  let [usernameRaw, nomorRaw, hariRaw] = text.split("|").map((v) => (v || "").trim());

  const username = String(usernameRaw || "").toLowerCase();
  const phone = normalizePhone(nomorRaw);
  const days = parseInt(hariRaw);

  if (isNaN(days) || days <= 0 || days > 365)
    return Reply("Durasi tidak valid. Silakan masukkan angka antara 1 hingga 365 hari.");
  if (!/^[a-z0-9]{3,15}$/.test(username))
    return Reply("Username tidak memenuhi syarat. Hanya diperbolehkan huruf kecil dan angka dengan panjang 3-15 karakter.");
  if (!phone || phone.length < 10) return Reply("Format nomor tujuan tidak valid.");

  const spec = specs[cmd];
  const ram = spec.ram;
  const disknya = spec.disk;
  const cpu = spec.cpu;

  try {
    await m.reply("Sedang memproses pembuatan panel. Mohon tunggu sebentar...");

    const allocations = await getServerAllocations(loc);
    let defaultAllocation = null;
    if (allocations.length > 0) {
      defaultAllocation = allocations[0].attributes.id;
    }

    const usersDB = loadUsersDB();
    let userEntry = usersDB.find((u) => String(u.phone) === String(phone));

    let panelUser;
    let password;

    if (userEntry) {
      const checkUserRes = await apiGET(`/users/${userEntry.userId}`);
      if (!checkUserRes.ok) {
        const usersDB = loadUsersDB();
        const newUsersDB = usersDB.filter(u => String(u.phone) !== String(phone));
        saveUsersDB(newUsersDB);
        userEntry = null;
      }
    }

    if (!userEntry) {
      const email = `${username}@gmail.com`;
      const first_name = toServerName(username);
      password = username + crypto.randomBytes(2).toString("hex");

      const checkRes = await apiGET(`/users?filter[username]=${encodeURIComponent(username)}`);
      if (checkRes.ok) {
        const checkData = await checkRes.json();
        if (checkData?.data?.length > 0) {
          const u = checkData.data[0].attributes;
          return Reply(`Username ${u.username} telah digunakan oleh email ${u.email}. Silakan pilih username yang berbeda.`);
        }
      }

      const createUserRes = await apiPOST("/users", {
        email: email,
        username: username,
        first_name: first_name,
        last_name: "USER",
        password: password,
      });

      if (!createUserRes.ok) {
        const errorData = await createUserRes.json().catch(() => ({}));
        return Reply(`Pembuatan user gagal.\nDetail: ${JSON.stringify(errorData?.errors?.[0] || errorData)}`);
      }

      const createUserData = await createUserRes.json();
      panelUser = createUserData.attributes || createUserData.data?.attributes || createUserData;

      userEntry = {
        phone: phone,
        userId: panelUser.id,
        username: panelUser.username,
        email: panelUser.email,
        password: password,
        createdAt: Date.now(),
      };

      const usersDB = loadUsersDB();
      usersDB.push(userEntry);
      saveUsersDB(usersDB);
    } else {
      panelUser = { id: userEntry.userId, username: userEntry.username, email: userEntry.email };
      password = userEntry.password;
    }

    const realUserId = panelUser.id || panelUser.attributes?.id;
    if (!realUserId) {
      return Reply(`Terjadi kesalahan sistem saat membaca ID User dari panel.`);
    }

    const eggRes = await apiGET(`/nests/${nestid}/eggs/${egg}`);
    if (!eggRes.ok) {
      return Reply(`Pengambilan data egg gagal. Pastikan Egg ID (${egg}) dan Nest ID (${nestid}) benar.`);
    }
    const eggData = await eggRes.json();
    const startup_cmd = eggData.attributes.startup || "npm start";
    const docker_image = eggData.attributes.docker_image || "ghcr.io/parkervcp/yolks:nodejs_20";

    const serverName = toServerName(username);

    const createServerPayload = {
      name: serverName,
      description: `Server dibuat pada ${new Date().toLocaleDateString("id-ID")}`,
      user: realUserId,
      egg: parseInt(egg),
      docker_image: docker_image,
      startup: startup_cmd,
      environment: {
        INST: "npm install",
        USER_UPLOAD: "0",
        AUTO_UPDATE: "0",
        CMD_RUN: "npm start"
      },
      limits: {
        memory: ram === 0 ? null : ram,
        swap: 0,
        disk: disknya,
        io: 500,
        cpu: cpu === 0 ? null : cpu
      },
      feature_limits: {
        databases: 5,
        backups: 5,
        allocations: 5
      },
      deploy: {
        locations: [parseInt(loc)],
        dedicated_ip: false,
        port_range: []
      }
    };

    if (defaultAllocation) {
      createServerPayload.allocation = { default: defaultAllocation };
    }

    const createServerRes = await apiPOST("/servers", createServerPayload);

    if (!createServerRes.ok) {
      const errorData = await createServerRes.json().catch(() => ({}));
      return Reply(`Pembuatan server gagal.\nDetail: ${JSON.stringify(errorData?.errors?.[0] || errorData)}`);
    }

    const createServerData = await createServerRes.json();
    const server = createServerData.attributes;
    const now = Date.now();
    const expiresAt = now + days * DAY_MS;

    upsertPanel(server.id, {
      serverId: server.id,
      name: server.name,
      owner: phone,
      username: panelUser.username,
      email: panelUser.email,
      reseller: isReseller ? m.sender : null,
      expiresAt: expiresAt,
      suspended: false,
      created: now,
      lastRenewed: now,
      notified: false,
      spec: { ram: ram, disk: disknya, cpu: cpu, type: cmd },
    });

    const expiryDate = new Date(expiresAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    const ramDisplay = ram === 0 ? "Unlimited" : (ram / 1024).toFixed(1) + "GB";
    const diskDisplay = disknya === 0 ? "Unlimited" : (disknya / 1024).toFixed(1) + "GB";
    const cpuDisplay = cpu === 0 ? "Unlimited" : cpu + "%";

    const teks = `╭─⬣「 INFORMASI PANEL 」⬣
│
├─ Detail Akun
│  ├─ 👤 Username: ${panelUser.username}
│  ├─ 🔑 Password: ${password}
│  └─ 🌐 Halaman Login: ${global.domain}
│
├─ Spesifikasi Layanan
│  ├─ 💾 RAM: ${ramDisplay}
│  ├─ 💽 Disk: ${diskDisplay}
│  └─ ⚡ CPU: ${cpuDisplay}
│
├─ Detail Server
│  ├─ 🏷️ Nama: ${server.name}
│  ├─ 🆔 Server ID: ${server.id}
│  ├─ ⏰ Durasi Sewa: ${days} Hari
│  └─ 📅 Tanggal Expired: ${expiryDate}
│
╰─⬣

⚠️ Syarat & Ketentuan Berlaku:
- Dilarang menyebarkan atau menampilkan tautan panel kepada publik.
- Jika melakukan tangkapan layar, tautan panel wajib disensor.
- Harap menjaga kerahasiaan data panel Anda untuk menghindari penyalahgunaan.
- Garansi hanya diproses jika seluruh syarat dan ketentuan terpenuhi.
- Dilarang keras menggunakan layanan untuk aktivitas ilegal.`;

    const targetJid = `${phone}@s.whatsapp.net`;

    if (m.isGroup)
      await Reply("Panel berhasil dibuat. Data login telah dikirimkan ke nomor yang didaftarkan.");

    try {
      await alip.sendMessage(targetJid, { text: teks }, { quoted: m });
    } catch (e) {
      console.error("Gagal mengirim data login ke target:", e);
      await Reply(`Panel berhasil dibuat, namun pengiriman data login ke nomor ${phone} gagal.\nPastikan nomor tersebut telah terdaftar di WhatsApp.`);
    }

    return;
  } catch (err) {
    console.error("Kesalahan pembuatan panel:", err);
    return Reply(`Terjadi kesalahan sistem saat memproses panel.\n${err?.message || err}`);
  }
};

handler.command = ["1gb", "2gb", "3gb", "4gb", "5gb", "6gb", "7gb", "unlimited", "unli"];

module.exports = handler;
