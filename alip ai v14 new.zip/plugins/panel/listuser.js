const {
  ensureDB,
  loadUsersDB,
  loadPanelDB,
  normalizePhone,
  isResellerFn,
  apiGET,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  if (!isCreator && !isReseller) {
    return Reply("Maaf, akses ditolak. Fitur ini terbatas untuk Reseller dan Owner.");
  }

  try {
    await m.reply("Sedang menghimpun data pengguna dan server...");

    const srvRes = await apiGET("/servers");
    if (!srvRes.ok) return Reply("Terjadi kendala saat mengambil data server.");
    const srvData = await srvRes.json();
    const servers = srvData.data || [];

    const usrRes = await apiGET("/users?per_page=200");
    if (!usrRes.ok) return Reply("Terjadi kendala saat mengambil data pengguna.");
    const usrData = await usrRes.json();
    const users = usrData.data || [];

    const usersDB = loadUsersDB();
    const panelDB = loadPanelDB();

    const countByUserId = {};
    for (const s of servers) {
      const uid = s?.attributes?.user;
      if (!uid) continue;
      countByUserId[uid] = (countByUserId[uid] || 0) + 1;
    }

    const allowedUserIdSet = new Set();
    if (!isCreator && isReseller) {
      for (const p of panelDB) {
        if (String(p.reseller || "") === String(m.sender)) {
          const phone = normalizePhone(p.owner || "");
          const u = usersDB.find((x) => String(x.phone) === String(phone));
          if (u?.userId) allowedUserIdSet.add(u.userId);
        }
      }
    }

    const admins = [];
    const normals = [];

    for (const u of users) {
      const a = u.attributes || {};
      const uid = a.id;

      if (!isCreator && isReseller) {
        if (!allowedUserIdSet.has(uid)) continue;
      }

      const isAdmin = !!a.root_admin || uid === 1;
      if (isAdmin) admins.push(u);
      else normals.push(u);
    }

    normals.sort((A, B) => {
      const aId = A.attributes?.id;
      const bId = B.attributes?.id;
      const aC = countByUserId[aId] || 0;
      const bC = countByUserId[bId] || 0;
      return bC - aC;
    });

    let out = `╭─⬣「 DAFTAR PENGGUNA 」⬣\n│\n`;

    if (isCreator && admins.length) {
      out += `├─ 👑 ADMIN PANEL\n`;
      let i = 0;
      for (const u of admins) {
        const a = u.attributes || {};
        const uid = a.id;
        const uname = a.username || "-";
        const email = a.email || "-";
        const total = countByUserId[uid] || 0;
        out += `│  ${++i}. ${uname}\n`;
        out += `│     ✉️ ${email}\n`;
        out += `│     🖥️ Jumlah Server: ${total}\n`;
      }
      out += `│\n`;
    }

    out += `├─ 👥 PENGGUNA LAYANAN\n`;
    if (!normals.length) {
      out += `│  (Tidak ada data)\n`;
    } else {
      let n = 0;
      for (const u of normals) {
        const a = u.attributes || {};
        const uid = a.id;
        const uname = a.username || "-";
        const email = a.email || "-";
        const total = countByUserId[uid] || 0;

        const local = usersDB.find((x) => String(x.userId) === String(uid));
        const phone = local?.phone ? `@${local.phone}` : "-";

        out += `│  ${++n}. ${uname} (${phone})\n`;
        out += `│     ✉️ ${email}\n`;
        out += `│     🖥️ Jumlah Server: ${total}\n`;
      }
    }

    out += `│\n╰─⬣`;
    return Reply(out);
  } catch (e) {
    console.error("ListUser Error:", e);
    return Reply("Pengambilan daftar pengguna gagal diproses.");
  }
};

handler.command = ["listuser"];

module.exports = handler;
