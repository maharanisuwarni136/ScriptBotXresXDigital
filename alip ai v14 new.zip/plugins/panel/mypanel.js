const {
  ensureDB,
  loadUsersDB,
  loadPanelDB,
  savePanelDB,
  normalizePhone,
  daysLeftFromExpiry,
  checkServerExists,
  suspendServer,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  try {
    const phone = normalizePhone(m.sender.split("@")[0]);
    const usersDB = loadUsersDB();
    const panelDB = loadPanelDB();

    const user = usersDB.find((u) => u.phone === phone);
    const myServers = panelDB.filter((p) => String(p.owner || "") === String(phone));

    if (!user || myServers.length === 0) return Reply("Anda saat ini belum memiliki layanan server yang aktif.");

    let suspendedNow = 0;
    for (const p of myServers) {
      const dLeft = daysLeftFromExpiry(p.expiresAt);
      if (dLeft <= 0 && !p.suspended && p.serverId) {
        const exists = await checkServerExists(p.serverId);
        if (exists) {
          const ok = await suspendServer(p.serverId);
          if (ok) {
            p.suspended = true;
            suspendedNow++;
          }
        } else {
          p.suspended = true;
          suspendedNow++;
        }
      }
    }
    savePanelDB(panelDB);

    let teks = `╭─⬣「 LAYANAN ANDA 」⬣\n│\n`;
    teks += `├─ 👤 Pengguna: ${user.username}\n`;
    teks += `├─ 📱 Kontak: ${phone}\n`;
    teks += `├─ 🖥️ Total Layanan: ${myServers.length}\n`;
    if (suspendedNow > 0) teks += `├─ 🧷 Ditangguhkan otomatis: ${suspendedNow} (Kadaluarsa)\n`;
    teks += `│\n`;
    teks += `├─ Daftar Layanan Aktif:\n`;

    let i = 0;
    for (const p of myServers) {
      const dLeft = daysLeftFromExpiry(p.expiresAt);
      const status = dLeft > 0 ? `🟢 ${dLeft} hari` : `🔴 Kadaluarsa${p.suspended ? " / Ditangguhkan" : ""}`;
      const expDate = p.expiresAt ? new Date(Number(p.expiresAt)).toLocaleDateString("id-ID") : "-";
      teks += `│  ${++i}. ${p.name || "Tanpa Nama"} — ${status} (Hingga: ${expDate})\n`;
    }

    teks += `│\n╰─⬣\n\n🔒 Catatan: Data login dirahasiakan untuk menjaga keamanan akun Anda.`;
    return Reply(teks);
  } catch (e) {
    console.error("MyPanel Error:", e);
    return Reply("Pengambilan informasi layanan gagal diproses.");
  }
};

handler.command = ["mypanel"];

module.exports = handler;
