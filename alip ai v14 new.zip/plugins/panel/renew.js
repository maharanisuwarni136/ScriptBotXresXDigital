const {
  ensureDB,
  loadPanelDB,
  savePanelDB,
  upsertPanel,
  fallbackPrefix,
  isResellerFn,
  DAY_MS,
  daysLeftFromExpiry,
  apiGET,
  unsuspendServer,
  clearNotifState,
  startExpirationWatcher
} = require("../../lib/cpanelHelper");

let handler = async (m, { alip, command, text, isCreator, Reply }) => {
  ensureDB();

  const domain = global.domain;
  const apikey = global.apikey;
  const nestid = global.nestid;
  const egg = global.egg;
  const loc = global.loc;

  if (!domain || !apikey || !nestid || !egg || !loc) {
    return Reply("Maaf, pengaturan panel belum lengkap di global settings.");
  }

  const isReseller = isResellerFn(m.sender);

  if (!global._expirationStarted) {
    startExpirationWatcher(alip);
    global._expirationStarted = true;
  }

  try {
    if (!text) {
      const res = await apiGET("/servers");
      if (!res.ok) return Reply("Pengambilan data server gagal diproses.");

      const data = await res.json();
      const allPanels = loadPanelDB();

      const myServers = (data.data || []).filter((s) => {
        if (isCreator) return true;
        const panel = allPanels.find((p) => String(p.serverId) === String(s.attributes.id));
        return panel && panel.reseller === m.sender;
      });

      if (myServers.length === 0) return Reply("Tidak ditemukan server yang memenuhi syarat untuk diperpanjang.");

      let message = `🔄 SERVER TERSEDIA UNTUK PERPANJANGAN\n\n`;
      let n = 0;

      for (const s of myServers) {
        const serverId = s.attributes.id;
        const serverName = s.attributes.name;

        const panel = allPanels.find((p) => String(p.serverId) === String(serverId));
        const dLeft = panel ? daysLeftFromExpiry(panel.expiresAt) : 0;
        const status = panel
          ? dLeft > 0
            ? `🟢 (${dLeft} hari)`
            : `🔴 (Kadaluarsa${panel.suspended ? " / Ditangguhkan" : ""})`
          : `⚪ (Tidak ada data di database)`;

        message += `${++n}. ${serverName}\n`;
        message += `   🆔 ID Server: ${serverId}\n`;
        message += `   ⏰ Status: ${status}\n`;
        message += `   🔄 Perintah: ${fallbackPrefix}renew ${serverId}\n\n`;
      }

      return Reply(message);
    }

    const serverId = Number(String(text).trim());
    if (!serverId) return Reply(`Format salah. Gunakan: ${fallbackPrefix}renew <ID Server>`);

    const verifyRes = await apiGET(`/servers/${serverId}`);
    if (!verifyRes.ok) {
      if (verifyRes.status === 404) {
        const db = loadPanelDB();
        const newDB = db.filter((p) => String(p.serverId) !== String(serverId));
        savePanelDB(newDB);
        clearNotifState(serverId);
        return Reply(`ID Server ${serverId} tidak terdaftar. Database telah disesuaikan.`);
      }
      return Reply(`Verifikasi server gagal. Kode status: ${verifyRes.status}`);
    }

    const verifyData = await verifyRes.json();
    const server = verifyData.attributes;

    const db = loadPanelDB();
    const panel = db.find((p) => String(p.serverId) === String(serverId));

    if (!isCreator && (!panel || panel.reseller !== m.sender)) {
      return Reply(`Maaf, Anda tidak memiliki akses untuk memperpanjang server ${server.name}.`);
    }

    const days = 30;
    const now = Date.now();

    const oldExp = panel?.expiresAt ? Number(panel.expiresAt) : 0;
    const base = oldExp > now ? oldExp : now;
    const newExpiry = base + days * DAY_MS;

    upsertPanel(serverId, {
      expiresAt: newExpiry,
      lastRenewed: now,
      suspended: false,
      name: panel?.name || server?.name,
    });

    clearNotifState(serverId);

    await unsuspendServer(serverId).catch(() => {});

    const expiredDate = oldExp ? new Date(oldExp) : new Date(now);
    const newDate = new Date(newExpiry);

    const successText = `✅ PERPANJANGAN SERVER BERHASIL

🏷️ Nama Layanan: ${server.name}
🆔 ID Server: ${serverId}
➕ Penambahan Durasi: ${days} hari
📅 Masa Aktif Sebelumnya: ${expiredDate.toLocaleDateString("id-ID")}
📅 Masa Aktif Baru: ${newDate.toLocaleDateString("id-ID")}

Layanan Anda telah berhasil diperpanjang.`;

    return Reply(successText);
  } catch (error) {
    console.error("Renew Error:", error);
    return Reply(`Terjadi kendala sistem: ${error?.message || error}`);
  }
};

handler.command = ["renew", "renewserver"];

module.exports = handler;
