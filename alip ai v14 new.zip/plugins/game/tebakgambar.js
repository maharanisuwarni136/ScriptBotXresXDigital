/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const { startGame } = require('../../lib/game.js');

module.exports = async (m, { alip, Reply, isRegistered, isCreator }) => {
    await startGame('tebakgambar', m, alip, Reply, isRegistered, isCreator);
};

module.exports.command = ['tebakgambar'];
