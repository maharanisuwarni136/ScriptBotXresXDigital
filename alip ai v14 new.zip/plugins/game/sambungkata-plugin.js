/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const { handleSambungKata } = require('../../lib/sambungkata.js');

module.exports = async (m, { alip, command, args }) => {
    await handleSambungKata(alip, m, command, args);
};

module.exports.command = ['sambungkata2', 'sk'];
