/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const tictactoe = require('../../lib/tictactoe.js');

module.exports = async (m, { alip, Reply, command, isCreator, isRegistered, isPrem, checkLimit, addLimit, args, text }) => {
    switch (command) {
        case 'tictactoe':
        case 'ttt':
        case 'tttplay': {
            const result = await tictactoe.handleNewGame(m, args, Reply, alip, isCreator, checkLimit, addLimit, isRegistered, isPrem, global.mess);
            if (result) Reply(result);
            break;
        }

        case 'tttmove': {
            const result = await tictactoe.handleMove(m, text, Reply, alip);
            if (result) Reply(result);
            break;
        }

        case 'tttresign':
        case 'tttsurrender': {
            const result = await tictactoe.handleResign(m, Reply);
            if (result) Reply(result);
            break;
        }

        case 'tttboard':
        case 'tttstatus': {
            const result = await tictactoe.handleBoard(m, Reply);
            if (result) Reply(result);
            break;
        }

        case 'tttclean':
        case 'tttcleanup': {
            if (!isCreator) return Reply('Command owner only');
            const result = await tictactoe.handleCleanup(Reply);
            if (result) Reply(result);
            break;
        }
    }
};

module.exports.command = [
    'tictactoe', 'ttt', 'tttplay', 'tttmove', 'tttresign', 'tttsurrender',
    'tttboard', 'tttstatus', 'tttclean', 'tttcleanup'
];

module.exports.before = async (m, { alip, Reply, isCmd }) => {

};
