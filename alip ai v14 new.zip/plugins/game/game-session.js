const fs = require('fs');
const { getWIBTime, safeReadJSON, limitBonusPath } = require('../../lib/game.js');

module.exports = async (m, { Reply, command }) => {
    if (command === "nyerah" || command === "menyerah") {
        if (global.gameSessions && global.gameSessions[m.chat]) {
            let session = global.gameSessions[m.chat];
            clearTimeout(session.timeout);
            let jawabanTampil = Array.isArray(session.jawaban) ? session.jawaban.join(" / ") : session.jawaban;
            Reply(` Yah, kamu menyerah 🏳️\nJawabannya adalah: *${jawabanTampil}*`);
            delete global.gameSessions[m.chat];
        } else {
            Reply("Tidak ada game yang sedang berlangsung untuk diserahkan.");
        }
    }
};

module.exports.command = ["nyerah", "menyerah"];

module.exports.before = async (m, { Reply, isCmd, botNumber }) => {
    global.gameSessions = global.gameSessions || {};
    if (!isCmd && m.isGroup && global.gameSessions[m.chat]) {
        const session = global.gameSessions[m.chat];
        const quotedMsg = m.quoted ? m.quoted : false;
        if (quotedMsg && quotedMsg.id === session.messageId) {
            if (m.sender === botNumber) return;
            const jawabanBenar = session.jawaban;
            const teksUser = (m.text || "").toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

            let benar = false;
            if (Array.isArray(jawabanBenar)) {
                benar = jawabanBenar.some(j => teksUser.includes(j.toLowerCase()));
            } else {
                benar = teksUser === jawabanBenar.toLowerCase();
            }

            if (benar) {
                clearTimeout(session.timeout);
                let jawabanTampil = Array.isArray(jawabanBenar) ? jawabanBenar.join(" / ") : jawabanBenar;
                const limitReward = Math.floor(Math.random() * 5) + 1;

                const bonusDB = safeReadJSON(limitBonusPath, {});
                const today = getWIBTime().toISOString().split('T')[0];

                if (!bonusDB[m.sender] || bonusDB[m.sender].date !== today) {
                    bonusDB[m.sender] = { bonus: 0, date: today };
                }

                bonusDB[m.sender].bonus += limitReward;
                fs.writeFileSync(limitBonusPath, JSON.stringify(bonusDB, null, 2));

                Reply(`✅ *Jawaban Benar!* \nJawabannya adalah: *${jawabanTampil}*\n\nSelamat kepada @${m.sender.split('@')[0]}! 🎉\n🎁 Kamu mendapatkan hadiah *+${limitReward} Limit Bot!*`, [m.sender]);

                delete global.gameSessions[m.chat];
            } else {
                Reply(`❌ *Jawaban Salah* untuk soal ini. Coba lagi!`);
            }
        }
    }
};
