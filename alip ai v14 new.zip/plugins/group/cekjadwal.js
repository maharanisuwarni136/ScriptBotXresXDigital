const { loadJadwal } = require('../../lib/autogcHelper');

let handler = async (m, { alip, isCreator, text, Reply, example, command }) => {
    if (!m.isGroup) return Reply(global.mess.group);

    let dbCek = loadJadwal();
    let data = dbCek[m.chat] || {};

    let close = data.closeTime || '❌ Belum diatur';
    let open = data.openTime || '❌ Belum diatur';
    let status = m.metadata && m.metadata.announce ? '🔒 TERTUTUP' : '🔓 TERBUKA';

    Reply(`╭─❏ *Jadwal Grup*\n│▣ Tutup : ${close}\n│▣ Buka : ${open}\n│▣ Status : ${status}\n╰──────────❏`);
};

handler.help = ['cekjadwal'];
handler.tags = ['group'];
handler.command = ['cekjadwal'];

module.exports = handler;
