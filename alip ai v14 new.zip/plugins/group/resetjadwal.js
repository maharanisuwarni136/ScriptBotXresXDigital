const { loadJadwal, saveJadwal } = require('../../lib/autogcHelper');

let handler = async (m, { alip, isCreator, text, Reply, example, command }) => {
    if (!m.isGroup) return Reply(global.mess.group);
    if (!m.isAdmin && !isCreator) return Reply(global.mess.admin);

    let dbReset = loadJadwal();
    if (!dbReset[m.chat]) return Reply('❌ Tidak ada jadwal untuk grup ini');

    delete dbReset[m.chat];
    saveJadwal(dbReset);
    Reply(global.mess.done || '✅ Berhasil mereset jadwal grup.');
};

handler.help = ['resetjadwal'];
handler.tags = ['group'];
handler.command = ['resetjadwal'];

module.exports = handler;
