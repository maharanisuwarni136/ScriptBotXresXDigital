const fs = require("fs");
const path = require("path");

const schedulePath = './library/database/schedule.json';

let handler = async (m, { alip, isCreator, text, Reply, example, command }) => {
    if (!m.isGroup) return Reply(global.mess.group);
    if (!m.isAdmin && !isCreator) return Reply(global.mess.admin);

    if (!fs.existsSync(schedulePath)) {
        fs.writeFileSync(schedulePath, JSON.stringify({ messages: [] }, null, 2));
    }

    const cleanText = text ? text.trim() : '';

    // Handle commands without pipe (|)
    if (!cleanText.includes('|')) {
        const cmd = cleanText.toLowerCase();
        if (cmd === 'list' || cmd === 'daftar') {
            const data = JSON.parse(fs.readFileSync(schedulePath));
            const groupMessages = data.messages.filter(msg => msg.chat === m.chat);

            if (groupMessages.length === 0) return Reply('📭 Tidak ada jadwal posting di grup ini.');

            let text = '📅 *Daftar Jadwal Posting* (Otomatis Hidetag)\n\n';
            groupMessages.forEach((msg, i) => {
                text += `*${i+1}. ${msg.isMonthly ? 'BULANAN' : 'DURASI'}*\n`;
                if (msg.isMonthly) {
                    text += `📅 Setiap Tanggal: ${msg.dayOfMonth}\n`;
                } else {
                    const timeLeft = Math.max(0, Math.floor((msg.timestamp - Date.now()) / 60000));
                    text += `⏰ Target: ${msg.scheduledFor}\n`;
                    text += `⏳ Sisa: ${timeLeft} menit lagi\n`;
                }
                text += `🖼️ Media: ${msg.mediaType ? msg.mediaType.toUpperCase() : 'Tidak Ada'}\n`;
                text += `📝 Pesan: ${msg.content.substring(0, 50)}${msg.content.length > 50 ? '...' : ''}\n\n`;
            });

            return Reply(text);
        } else if (cmd === 'clear' || cmd === 'bersihkan') {
            const data = JSON.parse(fs.readFileSync(schedulePath));
            const groupMessages = data.messages.filter(msg => msg.chat === m.chat);

            groupMessages.forEach(msg => {
                if (msg.mediaPath && fs.existsSync(msg.mediaPath)) {
                    try {
                        fs.unlinkSync(msg.mediaPath);
                    } catch (err) {}
                }
            });

            data.messages = data.messages.filter(msg => msg.chat !== m.chat);
            fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));
            return Reply(`✅ Semua jadwal posting di grup ini berhasil dibersihkan!`);
        } else if (cmd.startsWith('delete ') || cmd.startsWith('hapus ')) {
            const numStr = cmd.replace(/^(delete|hapus)\s+/, '').trim();
            const index = parseInt(numStr) - 1;
            const data = JSON.parse(fs.readFileSync(schedulePath));
            const groupMessages = data.messages.filter(msg => msg.chat === m.chat);

            if (isNaN(index) || index < 0 || index >= groupMessages.length) {
                return Reply('❌ Nomor tidak valid!');
            }

            const msgToDelete = groupMessages[index];
            if (msgToDelete.mediaPath && fs.existsSync(msgToDelete.mediaPath)) {
                try {
                    fs.unlinkSync(msgToDelete.mediaPath);
                } catch (err) {}
            }

            data.messages = data.messages.filter(msg =>
                !(msg.chat === msgToDelete.chat &&
                  msg.createdAt === msgToDelete.createdAt &&
                  msg.content === msgToDelete.content)
            );

            fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));
            return Reply(`✅ Jadwal posting #${index+1} berhasil dihapus!`);
        } else {
            return Reply(`📅 *FITUR JADWAL POSTING* (Otomatis Hidetag)\n\nGunakan:\n• \`.schedule <pesan>|<tanggal>\` - Tambah jadwal\n• \`.schedule list\` - Lihat jadwal\n• \`.schedule delete <no>\` - Hapus jadwal\n• \`.schedule clear\` - Hapus semua\n\n*Contoh:* \`.schedule Reset bulanan|1\` (Bisa sambil kirim/reply foto atau video)`);
        }
    }

    // Process scheduling with pipe
    const parts = cleanText.split('|');
    let message = '';
    let dayOfMonth = 0;

    const part0 = parts[0].trim();
    const part1 = parts[1].trim();

    const num0 = parseInt(part0);
    const num1 = parseInt(part1);

    if (!isNaN(num0) && num0 >= 1 && num0 <= 31) {
        dayOfMonth = num0;
        message = part1;
    } else if (!isNaN(num1) && num1 >= 1 && num1 <= 31) {
        dayOfMonth = num1;
        message = part0;
    } else {
        return Reply('❌ Tanggal tidak valid! Harus berupa angka antara 1 sampai 31.');
    }

    if (!message) return Reply('❌ Pesan tidak boleh kosong!');

    let mediaPath = '';
    let mediaType = '';

    const quoted = m.quoted;
    const mime = m.mime || quoted?.mime || '';

    if (/image/gi.test(mime)) {
        try {
            const buffer = await (quoted ? quoted.download() : m.download());
            if (buffer) {
                const dir = './library/database/schedule_media';
                if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
                const filename = `media_${Date.now()}_${Math.random().toString(36).substring(3)}.jpg`;
                mediaPath = path.join(dir, filename);
                fs.writeFileSync(mediaPath, buffer);
                mediaType = 'image';
            }
        } catch (e) {
            console.error("Gagal mengunduh media gambar:", e);
        }
    } else if (/video/gi.test(mime)) {
        try {
            const buffer = await (quoted ? quoted.download() : m.download());
            if (buffer) {
                const dir = './library/database/schedule_media';
                if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
                const filename = `media_${Date.now()}_${Math.random().toString(36).substring(3)}.mp4`;
                mediaPath = path.join(dir, filename);
                fs.writeFileSync(mediaPath, buffer);
                mediaType = 'video';
            }
        } catch (e) {
            console.error("Gagal mengunduh media video:", e);
        }
    }

    const data = JSON.parse(fs.readFileSync(schedulePath));

    data.messages.push({
        chat: m.chat,
        content: message,
        isMonthly: true,
        dayOfMonth: dayOfMonth,
        mediaPath: mediaPath,
        mediaType: mediaType,
        createdBy: m.sender,
        createdAt: Date.now(),
        lastSentMonth: ''
    });

    fs.writeFileSync(schedulePath, JSON.stringify(data, null, 2));

    let replyMsg = `✅ Jadwal posting berhasil ditambahkan!\n`;
    replyMsg += `📅 Setiap Tanggal: ${dayOfMonth}\n`;
    replyMsg += `🖼️ Media: ${mediaType ? mediaType.toUpperCase() : 'Tidak Ada'}\n`;
    replyMsg += `📢 Hidetag: Otomatis\n`;
    replyMsg += `📝 Pesan: ${message}`;
    
    Reply(replyMsg);
};

handler.command = ["schedule"];

module.exports = handler;
