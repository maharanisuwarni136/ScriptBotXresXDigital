const { loadJadwal, saveJadwal } = require('../../lib/autogcHelper');

let handler = async (m, { alip, isCreator, text, Reply, example, command }) => {
    if (!m.isGroup) return Reply(global.mess.group);
    if (!m.isAdmin && !isCreator) return Reply(global.mess.admin);
    if (!m.isBotAdmin) return Reply('❌ Bot harus menjadi admin agar bisa membuka/menutup grup!');

    if (!text) return Reply(example("21:00"));

    let [closeJam, closePesan] = text.split('|');
    closeJam = closeJam.trim();

    if (!/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(closeJam)) return Reply("❌ Format jam salah! Gunakan HH:MM (contoh: 21:00)");

    let dbJadwal = loadJadwal();
    if (!dbJadwal[m.chat]) dbJadwal[m.chat] = {};

    dbJadwal[m.chat].closeTime = closeJam;
    if (closePesan) dbJadwal[m.chat].closeMessage = closePesan.trim();
    delete dbJadwal[m.chat].lastClose;
    delete dbJadwal[m.chat].lastCloseTime;

    saveJadwal(dbJadwal);
    if (typeof global.runAutoGcCheck === 'function') {
        global.runAutoGcCheck();
    }
    Reply(`✅ Close Time diset jam ${closeJam} WIB`);
};

handler.help = ['setclosetime'];
handler.tags = ['group'];
handler.command = ['setclosetime'];

module.exports = handler;
