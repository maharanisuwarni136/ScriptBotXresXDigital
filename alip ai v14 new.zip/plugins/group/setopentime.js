const { loadJadwal, saveJadwal } = require('../../lib/autogcHelper');

let handler = async (m, { alip, isCreator, text, Reply, example, command }) => {
    if (!m.isGroup) return Reply(global.mess.group);
    if (!m.isAdmin && !isCreator) return Reply(global.mess.admin);
    if (!m.isBotAdmin) return Reply('❌ Bot harus menjadi admin agar bisa membuka/menutup grup!');

    if (!text) return Reply(example("05:00"));

    let [openJam, openPesan] = text.split('|');
    openJam = openJam.trim();

    if (!/^([0-1][0-9]|2[0-3]):[0-5][0-9]$/.test(openJam)) return Reply("❌ Format jam salah! Gunakan HH:MM (contoh: 05:00)");

    let dbJadwal2 = loadJadwal();
    if (!dbJadwal2[m.chat]) dbJadwal2[m.chat] = {};

    dbJadwal2[m.chat].openTime = openJam;
    if (openPesan) dbJadwal2[m.chat].openMessage = openPesan.trim();
    delete dbJadwal2[m.chat].lastOpen;
    delete dbJadwal2[m.chat].lastOpenTime;

    saveJadwal(dbJadwal2);
    if (typeof global.runAutoGcCheck === 'function') {
        global.runAutoGcCheck();
    }
    Reply(`✅ Open Time diset jam ${openJam} WIB`);
};

handler.help = ['setopentime'];
handler.tags = ['group'];
handler.command = ['setopentime'];

module.exports = handler;
