/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 */
const fs = require('fs');
const path = require('path');

let handler = async (m, { alip, command, isCreator, Reply }) => {
  if (!isRegistered(m.sender) && !isCreator)
    return Reply(global.mess.verifikasi);
  if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
    return Reply(global.mess.limit);

  addLimit(m.sender, global.isPrem(m.sender), isCreator);
  await alip.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
      const filePath = path.join(__dirname, '../../data/random_image/dadu.json');
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      const roll = data[Math.floor(Math.random() * data.length)];

      await alip.sendMessage(m.chat, {
          image: { url: roll.result },
          caption: `🎲 Hasil Dadu: *${roll.number}*`
      }, { quoted: m });

      await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
      console.error(e);
      await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      Reply("❌ Gagal memutar dadu.");
  }
}

handler.command = ["randomdadu"]
module.exports = handler;
