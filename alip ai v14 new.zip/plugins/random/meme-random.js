/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 */
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

let handler = async (m, { alip, command, isCreator, Reply }) => {
  if (!isRegistered(m.sender) && !isCreator)
    return Reply(global.mess.verifikasi);
  if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
    return Reply(global.mess.limit);

  addLimit(m.sender, global.isPrem(m.sender), isCreator);
  await alip.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
      let api = `https://api-faa.my.id/faa/meme`;
      const res = await fetch(api);
      if (!res.ok) throw new Error('Gagal mengambil meme online');
      const buffer = await res.buffer();
      await alip.sendMessage(m.chat, {
          image: buffer,
          caption: "🤣 Random Meme"
      }, { quoted: m });
      await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
      console.warn('[MEME ONLINE ERROR] Fallback ke meme lokal antiwork', e);
      try {
          const filePath = path.join(__dirname, '../../data/random_image/antiwork.json');
          const urls = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
          const randomUrl = urls[Math.floor(Math.random() * urls.length)];
          await alip.sendMessage(m.chat, {
              image: { url: randomUrl },
              caption: "🤣 Random Meme (Offline Fallback)"
          }, { quoted: m });
          await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
      } catch (err) {
          console.error(err);
          await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
          Reply("❌ Gagal mengambil meme.");
      }
  }
}

handler.command = ["randommeme"]
module.exports = handler;
