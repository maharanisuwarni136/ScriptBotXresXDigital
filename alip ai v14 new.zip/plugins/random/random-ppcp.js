/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 */
const fs = require('fs');
const path = require('path');

let handler = async (m, { alip, command, isCreator, Reply }) => {
  if (!isRegistered(m.sender) && !isCreator)
    return Reply(global.mess.verifikasi);
  if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
    return Reply(global.mess.limit);

  addLimit(m.sender, global.isPrem(m.sender), isCreator);
  await alip.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
      const filePath = path.join(__dirname, '../../data/random_image/ppcp.js');
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      const pair = data[Math.floor(Math.random() * data.length)];

      await alip.sendMessage(m.chat, {
          image: { url: pair.cowo },
          caption: "👦 Cowo"
      }, { quoted: m });

      await alip.sendMessage(m.chat, {
          image: { url: pair.cewe },
          caption: "👧 Cewe"
      }, { quoted: m });

      await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
      console.error(e);
      await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      Reply("❌ Gagal mengambil couple profile picture.");
  }
}

handler.command = ["randomppcp"]
module.exports = handler;
