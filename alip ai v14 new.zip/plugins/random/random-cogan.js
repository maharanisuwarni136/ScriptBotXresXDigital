/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 */
const fs = require('fs');
const path = require('path');

let handler = async (m, { alip, command, isCreator, Reply }) => {
  if (!isRegistered(m.sender) && !isCreator)
    return Reply(global.mess.verifikasi);
  if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
    return Reply(global.mess.limit);

  addLimit(m.sender, global.isPrem(m.sender), isCreator);
  await alip.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
      const filePath = path.join(__dirname, '../../data/random_image/cogan.json');
      if (!fs.existsSync(filePath)) throw new Error('Database not found');
      
      const urls = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      const randomUrl = urls[Math.floor(Math.random() * urls.length)];

      await alip.sendMessage(m.chat, {
          image: { url: randomUrl },
          caption: "📸 Random Cogan"
      }, { quoted: m });

      await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (e) {
      console.error(e);
      await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
      Reply("❌ Gagal mengambil gambar.");
  }
}

handler.command = ["randomcogan"]
module.exports = handler;
