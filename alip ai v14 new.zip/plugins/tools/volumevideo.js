/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const { exec } = require('child_process')
const fs = require('fs')
const path = require('path')
const util = require('util')
const execPromise = util.promisify(exec)

let handler = async (m, { alip, text, isCreator, isPremium, Reply, example }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/video/.test(mime)) return Reply('❌ Reply video yang mau diubah volumenya!')

    if (!text) return Reply(`📌 *Contoh:*\n.volvideo 50% \n.volvideo 200% `)

    const match = text.match(/^(\d+(?:\.\d+)?)%?$/)
    if (!match) return Reply('❌ Format salah! Gunakan angka persen\nContoh: .volvideo 50%, .volvideo 150%')

    let percent = parseFloat(match[1])
    if (isNaN(percent) || percent < 1 || percent > 500) {
        return Reply('❌ Volume harus antara 1% sampai 500%')
    }

    const volume = percent / 100

    await alip.sendMessage(m.chat, { react: { text: '🔊', key: m.key } })

    try {
        const media = await q.download()
        if (!media) throw new Error('Gagal download video')

        const tmpDir = './tmp'
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

        const inputPath = path.join(tmpDir, `video_${Date.now()}_input.mp4`)
        const outputPath = path.join(tmpDir, `video_${Date.now()}_output.mp4`)

        fs.writeFileSync(inputPath, media)

        await execPromise(`ffmpeg -i "${inputPath}" -vcodec copy -af "volume=${volume}" "${outputPath}"`)

        const result = fs.readFileSync(outputPath)

        await alip.sendMessage(m.chat, {
            video: result,
            mimetype: 'video/mp4',
            caption: `✅ *Volume video berhasil diubah*\n\n🔊 Volume: ${percent}%`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        fs.unlinkSync(inputPath)
        fs.unlinkSync(outputPath)

    } catch (error) {
        console.error('[VOLVIDEO ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        Reply(`❌ Gagal: ${error.message}`)
    }
}

handler.command = ['volvideo', 'volumevideo']
handler.help = ['volvideo <persen>']
handler.tags = ['video']
handler.premium = true

module.exports = handler