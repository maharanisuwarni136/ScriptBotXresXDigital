/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

let handler = async (m, { text, command, Reply, example }) => {
    if (!text) return Reply(example("text awal|test readmore"));

    let parts = text.split('|');
    let left = parts[0].trim();
    let right = parts.slice(1).join('|').trim();

    if (!right) return Reply("❌ Format salah! Gunakan: `teks awal|teks selengkapnya`\n\n*Contoh:*\n.readmore Halo|Ini teks tersembunyi");

    const readmoreChar = '\u200e'.repeat(4000);
    const result = `${left}${readmoreChar}\n${right}`;

    await Reply(result);
}

handler.command = ['readmore', 'spoiler', 'selengkapnya']
handler.help = ['readmore text awal|text selengkapnya']
handler.tags = ['tools']

module.exports = handler;
