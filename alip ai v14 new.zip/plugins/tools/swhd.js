/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const fs = require('fs');
const { exec } = require('child_process');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

let handler = async (m, { alip, text, command, isCreator, isPremium, Reply, example, isRegistered, checkLimit, addLimit }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem);
    if (!isRegistered(m.sender) && !isCreator) return Reply(global.mess.verifikasi);
    if (checkLimit(m.sender, isPremium, isCreator)) return Reply(global.mess.limit);
    if (!m.quoted) return Reply(example("dengan reply media dokumen (foto/video)"));

    const q = m.quoted;
    const msg = q.msg || q.message || q.documentMessage || q;
    const mime = msg.mimetype || "";

    if (!mime.includes('document') && !msg.documentMessage && !m.quoted.documentMessage) {
        return Reply('❌ Reply file yang dikirim dalam bentuk *Dokumen*!');
    }

    addLimit(m.sender, isPremium, isCreator);
    await alip.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    Reply(global.mess.wait);

    try {
        const targetMessage = msg.documentMessage ? msg.documentMessage : msg;
        const stream = await downloadContentFromMessage(targetMessage, 'document');
        let buffer = Buffer.from([]);

        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        if (mime.includes('image')) {
            await alip.sendMessage(m.chat, {
                image: buffer,
                caption: `乂  *SW HD*\n\nSiap di-forward ke status WhatsApp!`
            }, { quoted: m });

            await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        }
        else if (mime.includes('video')) {
            const timestamp = Date.now();
            const tempIn = `./tmp_in_${timestamp}.mp4`;
            const tempOut = `./tmp_out_${timestamp}.mp4`;

            fs.writeFileSync(tempIn, buffer);

            const ffCmd = `ffmpeg -y -i "${tempIn}" -c:v libx264 -crf 20 -preset slow -c:a aac -b:a 128k -vf "scale='min(720,iw)':-2" -pix_fmt yuv420p "${tempOut}"`;

            await new Promise((resolve, reject) => {
                exec(ffCmd, (err, stdout, stderr) => {
                    if (err) reject(new Error(stderr || err.message));
                    else resolve();
                });
            });

            const finalBuffer = fs.readFileSync(tempOut);

            await alip.sendMessage(m.chat, {
                video: finalBuffer,
                caption: `乂  *Proses di selesaikan*`
            }, { quoted: m });

            fs.unlinkSync(tempIn);
            fs.unlinkSync(tempOut);

            await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        }
        else {
            return Reply('❌ Dokumen yang direply bukan format foto atau video!');
        }

    } catch (e) {
        console.error('[SWHD ERROR]', e);
        await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        Reply(global.mess.error);
    }
}

handler.command = ['swhd', 'storyhd']
handler.help = ['swhd <reply dokumen foto/video>']
handler.tags = ['tools']
handler.premium = true

module.exports = handler;
