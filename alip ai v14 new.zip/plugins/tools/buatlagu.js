/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { alip, text, command, isCreator, isPremium, Reply, example }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem);
    if (!text) return Reply(example("Rip Indo, musik rap tentang korupsi dan tikus kantor"));

    let title = "AI Song";
    let prompt = text;
    if (text.includes(',')) {
        const parts = text.split(',');
        title = parts[0].trim();
        prompt = parts.slice(1).join(',').trim();
    }
    if (!prompt) prompt = title;

    try {
        Reply(global.mess.wait);
        await alip.sendMessage(m.chat, { react: { text: "🎵", key: m.key } });

        const startResponse = await axios.get(`${global.apialip}/ai/sunora`, {
            params: {
                apikey: global.apikeyalip,
                prompt: prompt,
                title: title
            },
            timeout: 60000
        });

        const startData = startResponse.data;
        if (!startData.status || !startData.jobId) {
            throw new Error(startData.message || "Gagal memulai pembuatan musik");
        }

        const jobId = startData.jobId;
        let attempts = 0;
        let maxAttempts = 60; // 5 menit max
        let result = null;

        while (attempts < maxAttempts) {
            await sleep(5000);
            try {
                const pollResponse = await axios.get(`${global.apialip}/ai/sunora/status`, {
                    params: {
                        apikey: global.apikeyalip,
                        jobId: jobId
                    },
                    timeout: 30000
                });
                const pollData = pollResponse.data;
                if (pollData && pollData.status) {
                    if (pollData.jobStatus === "completed") {
                        result = pollData.result;
                        break;
                    } else if (pollData.jobStatus === "failed") {
                        throw new Error("Pembuatan musik gagal di server.");
                    }
                }
            } catch (e) {
                console.error("[BUATLAGU POLL ERROR]", e.message);
            }
            attempts++;
        }

        if (!result) {
            throw new Error("Timeout: Musik tidak selesai dibuat setelah 5 menit.");
        }

        const music1 = result.music_1;
        const music2 = result.music_2;

        if (music1 && music1.music_url) {
            const caption1 = `🎵 *${music1.title || "AI Generated Song"} - Part 1*\n🤖 Model: ${music1.model_version || 'foxaihub'}`;
            if (music1.image_url) {
                await alip.sendMessage(m.chat, {
                    image: { url: music1.image_url },
                    caption: caption1
                }, { quoted: m });
            } else {
                await Reply(caption1);
            }
            await alip.sendMessage(m.chat, {
                audio: { url: music1.music_url },
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: m });
        }

        if (music2 && music2.music_url) {
            const caption2 = `🎵 *${music2.title || "AI Generated Song"} - Part 2*\n🤖 Model: ${music2.model_version || 'foxaihub'}`;
            if (music2.image_url) {
                await alip.sendMessage(m.chat, {
                    image: { url: music2.image_url },
                    caption: caption2
                }, { quoted: m });
            } else {
                await Reply(caption2);
            }
            await alip.sendMessage(m.chat, {
                audio: { url: music2.music_url },
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: m });
        }

        await alip.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[BUATLAGU ERROR]', e);
        await alip.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        let errorMsg = e.message || 'Gagal membuat lagu';
        if (e.response?.data?.message) errorMsg = e.response.data.message;
        Reply(`❌ ${errorMsg}`);
    }
}

handler.command = ['buatlagu', 'createsong']
handler.help = ['buatlagu judullagu,prompt']
handler.tags = ['ai', 'tools']
handler.premium = true

module.exports = handler;
