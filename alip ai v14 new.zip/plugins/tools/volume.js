/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const { exec } = require('child_process')
const fs = require('fs')
const path = require('path')
const util = require('util')
const execPromise = util.promisify(exec)

let handler = async (m, { alip, text, isCreator, isPremium, Reply, example }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/audio/.test(mime)) return Reply('❌ Reply audio yang mau diubah volumenya!')

    if (!text) return Reply(`📌 *Contoh:*\n.volume 50% (reply audio)\n.volume 200% (reply audio)`)

    const match = text.match(/^(\d+(?:\.\d+)?)%?$/)
    if (!match) return Reply('❌ Format salah! Gunakan angka persen\nContoh: .volume 50%, .volume 150%')

    let percent = parseFloat(match[1])
    if (isNaN(percent) || percent < 1 || percent > 500) {
        return Reply('❌ Volume harus antara 1% sampai 500%')
    }

    const volume = percent / 100

    await alip.sendMessage(m.chat, { react: { text: '🔊', key: m.key } })

    try {
        const media = await q.download()
        if (!media) throw new Error('Gagal download audio')

        const tmpDir = './tmp'
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

        const inputPath = path.join(tmpDir, `audio_${Date.now()}_input.mp3`)
        const outputPath = path.join(tmpDir, `audio_${Date.now()}_output.mp3`)

        fs.writeFileSync(inputPath, media)

        await execPromise(`ffmpeg -i "${inputPath}" -af "volume=${volume}" -c:a libmp3lame -q:a 2 "${outputPath}"`)

        const result = fs.readFileSync(outputPath)

        await alip.sendMessage(m.chat, {
            audio: result,
            mimetype: 'audio/mpeg',
            caption: `✅ *Volume berhasil diubah*\n\n🔊 Volume: ${percent}%`
        }, { quoted: m })

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

        fs.unlinkSync(inputPath)
        fs.unlinkSync(outputPath)

    } catch (error) {
        console.error('[VOLUME ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        Reply(`❌ Gagal: ${error.message}`)
    }
}

handler.command = ['volume']
handler.help = ['volume <persen> (reply audio)']
handler.tags = ['audio']
handler.premium = true

module.exports = handler