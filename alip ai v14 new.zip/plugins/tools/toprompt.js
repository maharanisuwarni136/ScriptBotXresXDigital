/*
 * © ALIP-AI
 * Since     : 2024 - 2026
 *
 * YouTube   : https://youtube.com/@alipclutch
 * Channel   : https://whatsapp.com/channel/0029VbC3jusK5cDD9mELOb18
 */

const axios = require('axios')
const { ImageUploadService } = require('node-upload-images')

async function uploadPixhost(buffer, filename = "file.jpg") {
    try {
        const service = new ImageUploadService('pixhost.to');
        const { directLink } = await service.uploadFromBinary(buffer, filename);
        return directLink;
    } catch (e) {
        console.error('Pixhost Upload Error:', e.message);
        return null;
    }
}

let handler = async (m, { alip, command, isCreator, isPremium, Reply }) => {
    if (!isCreator && !isPremium) return Reply(global.mess.prem)

    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/image/.test(mime)) return Reply(`❌ Reply gambar yang ingin diubah menjadi prompt dengan caption *.${command}*`)

    await alip.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        const media = await q.download()
        if (!media) throw new Error('Gagal mengunduh gambar')

        const imageUrl = await uploadPixhost(media, 'image.jpg')
        if (!imageUrl) throw new Error('Gagal mengunggah gambar ke server uploader')

        const apiUrl = `${global.apialip}/ai/img2prompt?apikey=${global.apikeyalip}&url=${encodeURIComponent(imageUrl)}`
        
        const response = await axios.get(apiUrl, {
            timeout: 60000
        })

        if (!response.data.status) {
            throw new Error(response.data.error || 'Gagal memproses gambar')
        }

        const promptText = response.data.result

        await alip.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
        
        Reply(`✨ *AI Image to Prompt* ✨\n\n\`\`\`${promptText}\`\`\``)

    } catch (error) {
        console.error('[TOPROMPT ERROR]', error)
        await alip.sendMessage(m.chat, { react: { text: '❌', key: m.key } })

        if (error.response?.status === 404) {
            Reply('❌ API tidak ditemukan!')
        } else if (error.code === 'ECONNABORTED') {
            Reply('⏱️ Request timeout, silakan coba lagi nanti!')
        } else {
            Reply(`❌ Gagal: ${error.message}`)
        }
    }
}

handler.command = ['toprompt', 'img2prompt']
handler.help = ['toprompt (reply gambar)']
handler.tags = ['ai', 'maker']
handler.premium = true

module.exports = handler
